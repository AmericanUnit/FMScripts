package com.deloitte.tririga.custom;

import com.deloitte.tririga.custom.message.RecordData;
import com.deloitte.tririga.custom.message.handler.RequestHandler;
import com.deloitte.tririga.custom.message.handler.ResponseHandler;
import com.deloitte.tririga.custom.message.handler.SOAPRequestHandler;
import com.deloitte.tririga.custom.message.handler.SOAPResponseHandler;
import com.deloitte.tririga.custom.props.BOConfig;
import com.deloitte.tririga.logger.CustomLogger;
import com.tririga.pub.workflow.CustomParamTaskResult;
import com.tririga.pub.workflow.Record;
import com.tririga.ws.TririgaWS;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.apache.log4j.Logger;
import org.apache.log4j.NDC;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.runtime.resource.loader.FileResourceLoader;

public class HttpClientCustomTask extends AbstractDataTransferCustomTask {
	private static final Logger log = CustomLogger.getCustomLogger().getDBLogger("HttpClientCustomTask");

	public CustomParamTaskResult execute(TririgaWS tririgaWS, Map params, long userID, Record[] args) {
		NDC.push(String.valueOf(userID));
		String firstParam = "";
		if (params != null) {
			Set keySet = params.keySet();
			firstParam = keySet == null ? "" : (String) keySet.toArray()[0];
		}

		Record[] var10 = args;
		int var9 = args.length;

		for (int var8 = 0; var8 < var9; ++var8) {
			Record record = var10[var8];
			com.tririga.ws.dto.Record[] records = null;
			RecordData recordData = new RecordData();
			StringBuffer responseBuffer = new StringBuffer();
			String requestPayload = "";
			RecordData respRecordData = null;

			try {
				records = tririgaWS.getRecordDataHeaders(new long[]{record.getId()});
				NDC.push("" + record.getId());
				log.info("BEGIN");
				HashMap<String, HashSet<String>> attributeMap = (HashMap) boAttributeMap
						.get(records[0].getObjectTypeName());
				BOConfig boConfig = (BOConfig) boConfigMap.get(records[0].getObjectTypeName());
				if (attributeMap == null) {
					attributeMap = this.updateObjectTypeMap(records[0], tririgaWS);
				}

				recordData.setRecordID(record.getId());
				recordData.setObjectType(records[0].getObjectTypeName());
				recordData.setAttributes(attributeMap);
				recordData.setModule(boConfig.getModule());
				recordData.fillRecordData(tririgaWS, boConfig);
				RequestHandler requestHandler = new SOAPRequestHandler();
				String reponsePayload = requestHandler.handleRequest(boConfig, firstParam, recordData);
				ResponseHandler responseHandler = new SOAPResponseHandler();
				respRecordData = responseHandler.handleResponse(recordData, firstParam, boConfig, reponsePayload);
				requestPayload = requestHandler.getRequestSubmitted();
				responseBuffer.append(reponsePayload);
			} catch (Exception var21) {
				log.error(var21.getMessage());
				responseBuffer.append(var21.getMessage());
				StackTraceElement[] var20;
				int var19 = (var20 = var21.getStackTrace()).length;

				for (int var18 = 0; var18 < var19; ++var18) {
					StackTraceElement element = var20[var18];
					responseBuffer.append(element.toString() + '\n');
					log.error(element.toString());
				}
			}

			this.savePayloadData(tririgaWS, respRecordData, requestPayload, responseBuffer.toString());
			log.info("END");
			NDC.pop();
		}

		NDC.remove();
		return new CustomParamTaskResult() {
			public Map getReturnParameters() {
				return null;
			}

			public boolean getExecutionWasSuccessful() {
				return true;
			}
		};
	}

	public static void main(String[] args) {
		new VelocityContext();
		VelocityEngine velocityEngine = new VelocityEngine();
		velocityEngine.setProperty("file.resource.loader.class", FileResourceLoader.class.getName());
		velocityEngine.init();
		Template boTemplate = velocityEngine.getTemplate("ProjectCreate.vtl");
	}
}