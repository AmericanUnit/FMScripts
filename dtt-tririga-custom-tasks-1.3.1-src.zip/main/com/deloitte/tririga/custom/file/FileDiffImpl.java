package com.deloitte.tririga.custom.file;

import com.github.difflib.DiffUtils;
import com.github.difflib.algorithm.DiffException;
import com.github.difflib.patch.AbstractDelta;
import com.github.difflib.patch.Patch;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import org.apache.log4j.Logger;

public class FileDiffImpl implements FileDiff {
	private static final Logger log = Logger.getLogger(FileDiffImpl.class);

	public boolean diffFile(File workingDir, FileDiffConfig diffConfig) throws IOException {
		File target = new File(workingDir, diffConfig.getTargetFileName());
		log.debug("Target file:" + target.getAbsolutePath());
		String srcFileName = diffConfig.getSourceFileNamePattern();
		SimpleDateFormat df = new SimpleDateFormat(srcFileName);
		Calendar calendar = Calendar.getInstance();
		File revisedFile = new File(workingDir, df.format(calendar.getTime()));

		int timeout;
		for (timeout = 0; !revisedFile.exists()
				&& timeout++ < 90; revisedFile = new File(workingDir, df.format(calendar.getTime()))) {
			calendar.add(5, -1);
		}

		timeout = 0;
		calendar.add(5, -1);
		df = new SimpleDateFormat(srcFileName);

		File originalFile;
		for (originalFile = new File(workingDir, df.format(calendar.getTime())); !originalFile.exists()
				&& timeout++ < 90; originalFile = new File(workingDir, df.format(calendar.getTime()))) {
			calendar.add(5, -1);
		}

		if (!originalFile.exists()) {
			log.info("Missing comparision file in the last 89 days");
			log.info("Creating a copy of:" + revisedFile.getAbsolutePath());
			Files.copy(revisedFile.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING);
		} else {
			List<String> original = Files.readAllLines(originalFile.toPath());
			List revised = Files.readAllLines(revisedFile.toPath());

			Patch patch;
			try {
				patch = DiffUtils.diff(original, revised);
			} catch (DiffException var15) {
				log.error("Error Occurred:" + var15.getMessage());
				log.error(var15.getClass().toString() + ", Caused by:" + var15.getCause());
				return false;
			}

			log.debug("Writing to file:" + patch.getDeltas().size());
			Files.write(target.toPath(), new byte[0], new OpenOption[]{StandardOpenOption.CREATE});
			Iterator var14 = patch.getDeltas().iterator();

			while (var14.hasNext()) {
				AbstractDelta<String> delta = (AbstractDelta) var14.next();
				Files.write(target.toPath(), delta.getTarget().getLines(), StandardOpenOption.APPEND);
			}
		}

		return true;
	}
}