package com.deloitte.tririga.custom.converter;

import com.deloitte.tririga.custom.AbstractDataTransferCustomTask;
import com.deloitte.tririga.custom.file.FileDiffConfig;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.log4j.Logger;

public class DelimitedFileFormatConverter implements FileFormatConverter {
	private static final Logger log = Logger.getLogger(DelimitedFileFormatConverter.class);

	public boolean convert(File workingDir, FileDiffConfig config) throws FileNotFoundException, IOException {
		LinkedProperties fixedWidthproperties = new LinkedProperties();
		fixedWidthproperties.load(new FileInputStream(
				new File(AbstractDataTransferCustomTask.getRootDir(), config.getFixedWidthConfigProperties())));
		CSVPrinter csvFilePrinter = null;
		CSVFormat csvFileFormat = CSVFormat.newFormat(config.getDelimiter()).withRecordSeparator('\n')
				.withAllowMissingColumnNames();
		File targetFile = new File(workingDir, config.getTargetFileName());
		String targetFileName = targetFile.getName();
		String fileNameWithoutExtn = targetFileName.substring(0, targetFileName.indexOf(46));
		File backup = new File(targetFile.getParentFile(), fileNameWithoutExtn);
		Files.copy(targetFile.toPath(), backup.toPath(), StandardCopyOption.REPLACE_EXISTING);
		FileOutputStream fileWriter = new FileOutputStream(targetFile);
		OutputStreamWriter writer = new OutputStreamWriter(fileWriter, StandardCharsets.UTF_8);
		csvFilePrinter = new CSVPrinter(writer, csvFileFormat);
		List<String> sourceLines = Files.readAllLines(backup.toPath());
		csvFilePrinter.printRecord(fixedWidthproperties.orderedKeys());
		Iterator var14 = sourceLines.iterator();

		while (var14.hasNext()) {
			String eachLine = (String) var14.next();
			csvFilePrinter.printRecord(getRowValue(eachLine, fixedWidthproperties));
		}

		csvFilePrinter.close();
		return true;
	}

	public static Iterable<?> getRowValue(String row, LinkedProperties properties) {
		List<String> rowValue = new LinkedList();
		int beginIndex = 0;

		int subStringIndx;
		for (Iterator var5 = properties.orderedKeys().iterator(); var5.hasNext(); beginIndex += subStringIndx) {
			Object key = var5.next();
			subStringIndx = Integer.parseInt((String) properties.get(key));

			try {
				rowValue.add(row.substring(beginIndex, beginIndex + subStringIndx));
			} catch (Exception var8) {
				log.error("Row:" + row);
				log.error(String.format("Could not parse[%s] within [%s,%s]", key, beginIndex, subStringIndx));
			}
		}

		return rowValue;
	}
}