package com.deloitte.tririga.custom.message;

import com.deloitte.tririga.custom.props.Association;
import com.deloitte.tririga.custom.props.BOConfig;
import com.tririga.ws.TririgaWS;
import com.tririga.ws.dto.AssociationFilter;
import com.tririga.ws.dto.DisplayLabel;
import com.tririga.ws.dto.Field;
import com.tririga.ws.dto.FieldSortOrder;
import com.tririga.ws.dto.Filter;
import com.tririga.ws.dto.IntegrationField;
import com.tririga.ws.dto.IntegrationRecord;
import com.tririga.ws.dto.IntegrationSection;
import com.tririga.ws.dto.QueryResponseColumn;
import com.tririga.ws.dto.QueryResponseHelper;
import com.tririga.ws.dto.QueryResult;
import com.tririga.ws.dto.Record;
import com.tririga.ws.dto.Section;
import com.tririga.ws.errors.InvalidArgumentException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import org.apache.log4j.Logger;

public class RecordData {
	private static final Logger log = Logger.getLogger(RecordData.class);
	protected static final String GENERAL_SECTION_NAME = "General";
	private long recordID;
	private String objectType;
	private String module;
	private HashMap<String, HashSet<String>> attributes;
	private HashMap<String, List<RecordData>> associatedRecords = new HashMap();
	private HashMap<String, String> recordData = new HashMap();

	public String getObjectType() {
		return this.objectType;
	}

	public void setObjectType(String objectType) {
		this.objectType = objectType;
	}

	public HashMap<String, HashSet<String>> getAttributes() {
		return this.attributes;
	}

	public void setAttributes(HashMap<String, HashSet<String>> attributes) {
		this.attributes = new HashMap(attributes);
	}

	public long getRecordID() {
		return this.recordID;
	}

	public void setRecordID(long recordID) {
		this.recordID = recordID;
	}

	public HashMap<String, String> getRecordData() {
		return this.recordData;
	}

	public void setRecordData(HashMap<String, String> recordData) {
		this.recordData = recordData;
	}

	public String getModule() {
		return this.module;
	}

	public void setModule(String module) {
		this.module = module;
	}

	public void fillRecordData(TririgaWS tririgaWS, BOConfig boConfig) throws Exception {
		Filter filter = new Filter();
		filter.setDataType(320);
		filter.setFieldName("triRecordIdSY");
		filter.setSectionName("RecordInformation");
		filter.setOperator(10);
		filter.setValue(String.valueOf(this.recordID));
		Filter[] filters = new Filter[]{filter};
		String[] objectTypes = new String[]{this.objectType};
		List<DisplayLabel> displayFieldList = new LinkedList();
		Set<String> sections = this.attributes.keySet();
		Iterator var9 = sections.iterator();

		while (var9.hasNext()) {
			String section = (String) var9.next();
			Iterator var11 = ((HashSet) this.attributes.get(section)).iterator();

			while (var11.hasNext()) {
				String attr = (String) var11.next();
				if (!attr.endsWith("NO")) {
					DisplayLabel dl = new DisplayLabel();
					dl.setFieldName(attr);
					dl.setLabel(attr);
					dl.setSectionName(section);
					displayFieldList.add(dl);
				}
			}
		}

		log.debug("Attribute Map:" + this.attributes);
		log.debug(this.module + ":" + this.objectType + ":" + this.recordID);
		DisplayLabel[] displayFields = new DisplayLabel[displayFieldList.size()];
		displayFields = (DisplayLabel[]) displayFieldList.toArray(displayFields);
		QueryResult queryResult = tririgaWS.runDynamicQuery("", this.module, objectTypes, (String[]) null, "", "", 2,
				displayFields, (DisplayLabel[]) null, (FieldSortOrder[]) null, filters, (AssociationFilter[]) null, 1,
				5);
		log.debug("queryResult size:" + queryResult.getTotalResults());
		QueryResponseHelper[] var13;
		int var38 = (var13 = queryResult.getQueryResponseHelpers()).length;

		int var16;
		for (int var36 = 0; var36 < var38; ++var36) {
			QueryResponseHelper helper = var13[var36];
			QueryResponseColumn[] var17;
			var16 = (var17 = helper.getQueryResponseColumns()).length;

			for (int var15 = 0; var15 < var16; ++var15) {
				QueryResponseColumn column = var17[var15];
				String section = column.getSection();
				if (((HashSet) this.attributes.get(section)).contains(column.getLabel())) {
					this.recordData.put(column.getLabel(), column.getDisplayValue());
				}
			}
		}

		log.debug("recordData:" + this.recordData);
		if (boConfig != null) {
			List<Association> assocList = boConfig.getAssocList();
			Iterator var39 = assocList.iterator();

			while (var39.hasNext()) {
				Association association = (Association) var39.next();
				com.tririga.ws.dto.Association[] associatedRecordsArr = tririgaWS.getAssociatedRecords(this.recordID,
						association.getString(), -1);
				List<RecordData> assocRecordDataList = new LinkedList();
				log.debug("assocRecordDataList.length:" + associatedRecordsArr.length);
				com.tririga.ws.dto.Association[] var44 = associatedRecordsArr;
				int var43 = associatedRecordsArr.length;

				for (var16 = 0; var16 < var43; ++var16) {
					com.tririga.ws.dto.Association assoc = var44[var16];
					log.debug(assoc.getAssociatedRecordId() + ":" + assoc.getObjectTypeName() + ":"
							+ assoc.getModuleName());
					tririgaWS.getRecordDataHeaders(new long[]{assoc.getAssociatedRecordId()});
					Section[] dtoSections = tririgaWS.getObjectType(assoc.getAssociatedObjectTypeId()).getSections();
					HashMap<String, HashSet<String>> attributeMap = new HashMap();
					Section[] var25 = dtoSections;
					int var24 = dtoSections.length;

					for (int var23 = 0; var23 < var24; ++var23) {
						Section section = var25[var23];
						Field[] fields = section.getFields();
						HashSet<String> fieldSet = new HashSet();
						Field[] var31 = fields;
						int var30 = fields.length;

						for (int var29 = 0; var29 < var30; ++var29) {
							Field field = var31[var29];
							fieldSet.add(field.getName());
						}

						attributeMap.put(section.getName(), fieldSet);
					}

					RecordData recordData = new RecordData();
					recordData.setRecordID(assoc.getAssociatedRecordId());
					recordData.setObjectType(assoc.getObjectTypeName());
					recordData.setAttributes(attributeMap);
					recordData.setModule(assoc.getModuleName());
					recordData.fillRecordData(tririgaWS,
							(BOConfig) boConfig.getParentBOConfigMap().get(assoc.getObjectTypeName()));
					assocRecordDataList.add(recordData);
				}

				this.associatedRecords.put(association.getName(), assocRecordDataList);
			}

		}
	}

	public void fillRecordData(TririgaWS tririgaWS, String sectionNameFilter, String fieldNameFilter, String fieldValue)
			throws Exception {
		Filter filter = new Filter();
		filter.setDataType(320);
		filter.setSectionName(sectionNameFilter);
		filter.setFieldName(fieldNameFilter);
		filter.setOperator(10);
		filter.setValue(fieldValue);
		Filter[] filters = new Filter[]{filter};
		String[] objectTypes = new String[]{this.objectType};
		List<DisplayLabel> displayFieldList = new LinkedList();
		Set<String> sections = this.attributes.keySet();
		Iterator var11 = sections.iterator();

		while (var11.hasNext()) {
			String section = (String) var11.next();
			Iterator var13 = ((HashSet) this.attributes.get(section)).iterator();

			while (var13.hasNext()) {
				String attr = (String) var13.next();
				if (!attr.endsWith("NO")) {
					DisplayLabel dl = new DisplayLabel();
					dl.setFieldName(attr);
					dl.setLabel(attr);
					dl.setSectionName(section);
					displayFieldList.add(dl);
				}
			}
		}

		log.debug("Attribute Map:" + this.attributes);
		log.debug(this.module + ":" + this.objectType + ":" + this.recordID);
		DisplayLabel[] displayFields = new DisplayLabel[displayFieldList.size()];
		displayFields = (DisplayLabel[]) displayFieldList.toArray(displayFields);
		QueryResult queryResult = tririgaWS.runDynamicQuery("", this.module, objectTypes, (String[]) null, "", "", 2,
				displayFields, (DisplayLabel[]) null, (FieldSortOrder[]) null, filters, (AssociationFilter[]) null, 1,
				5);
		log.debug("queryResult size:" + queryResult.getTotalResults());
		QueryResponseHelper[] var15;
		int var25 = (var15 = queryResult.getQueryResponseHelpers()).length;

		for (int var24 = 0; var24 < var25; ++var24) {
			QueryResponseHelper helper = var15[var24];
			QueryResponseColumn[] var19;
			int var18 = (var19 = helper.getQueryResponseColumns()).length;

			for (int var17 = 0; var17 < var18; ++var17) {
				QueryResponseColumn column = var19[var17];
				String section = column.getSection();
				if (((HashSet) this.attributes.get(section)).contains(column.getLabel())) {
					this.recordData.put(column.getLabel(), column.getDisplayValue());
				}
			}
		}

		log.debug("recordData:" + this.recordData);
	}

	public void saveRecordData(TririgaWS tririgaWS, String actionName) throws Exception {
		tririgaWS.saveRecord(new IntegrationRecord[]{this.getIntegrationRecord(tririgaWS, actionName)});
	}

	public HashMap<String, List<RecordData>> getAssociatedRecords() {
		return this.associatedRecords;
	}

	public void setAssociatedRecords(HashMap<String, List<RecordData>> associatedRecords) {
		this.associatedRecords = associatedRecords;
	}

	public IntegrationRecord getIntegrationRecord(TririgaWS tririgaWS, String actionName)
			throws InvalidArgumentException, Exception {
		Record[] records = tririgaWS.getRecordDataHeaders(new long[]{this.getRecordID()});
		Record record = records[0];
		IntegrationRecord integrationRecord = new IntegrationRecord();
		if (actionName == null || actionName.isEmpty()) {
			actionName = tririgaWS.getAvailableActions(new long[]{record.getId()})[0].getAvailableTransitions()[0]
					.getAction();
		}

		integrationRecord.setModuleId(record.getModuleId());
		integrationRecord.setObjectTypeId(record.getObjectTypeId());
		integrationRecord.setGuiId(record.getGuiId());
		integrationRecord.setObjectTypeName(record.getObjectTypeName());
		integrationRecord.setId(record.getId());
		integrationRecord.setActionName(actionName);
		IntegrationSection is = new IntegrationSection();
		is.setName("General");
		List<IntegrationField> fieldList = new ArrayList();
		HashMap<String, String> recordDataToSave = this.getRecordData();
		Iterator var10 = recordDataToSave.keySet().iterator();

		while (var10.hasNext()) {
			String attrName = (String) var10.next();
			IntegrationField field = new IntegrationField();
			field.setName(attrName);
			field.setValue((String) recordDataToSave.get(attrName));
			fieldList.add(field);
		}

		log.debug("Fields compiled:" + fieldList);
		is.setFields((IntegrationField[]) fieldList.toArray(new IntegrationField[0]));
		integrationRecord.setSections(new IntegrationSection[]{is});
		return integrationRecord;
	}
}