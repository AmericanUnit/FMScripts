package com.deloitte.tririga.custom.message.handler;

import com.deloitte.tririga.custom.FileTransferCustomTask;
import com.deloitte.tririga.custom.connection.IntegrationParameters;
import com.deloitte.tririga.custom.message.RecordData;
import com.deloitte.tririga.custom.message.handler.util.EpochDateTool;
import com.deloitte.tririga.custom.props.BOConfig;
import com.deloitte.tririga.custom.props.BOPropertiesReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.tools.generic.EscapeTool;
import org.apache.velocity.tools.generic.MathTool;
import org.apache.velocity.tools.generic.NumberTool;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.jasypt.properties.EncryptableProperties;

public class FileRequestHandler extends AbstractRequestHandler {
	private static final Logger log = Logger.getLogger(FileRequestHandler.class);

	public String handleRequest(BOConfig boConfig, String templateKey, RecordData recordData) {
		String returnMessage = null;

		try {
			IntegrationParameters integrationParameters = boConfig.getIntegrationParameters();
			log.info("Saving file to:" + integrationParameters.getOutputDir());
			StringWriter requestPayloadWriter = new StringWriter();
			VelocityContext velocityContext = new VelocityContext();
			velocityContext.put("dateTool", new EpochDateTool());
			velocityContext.put("esc", new EscapeTool());
			velocityContext.put("math", new MathTool());
			velocityContext.put("numberTool", new NumberTool());
			Template requestTemplate = velocityEngine
					.getTemplate((String) integrationParameters.getTemplateMap().get(templateKey));
			HashMap<String, String> recordDataValue = recordData.getRecordData();
			Iterator var11 = recordDataValue.keySet().iterator();

			while (var11.hasNext()) {
				String key = (String) var11.next();
				velocityContext.put(key, recordDataValue.get(key));
			}

			HashMap<String, List<RecordData>> assocRecordData = recordData.getAssociatedRecords();
			Iterator var12 = assocRecordData.keySet().iterator();

			String key;
			while (var12.hasNext()) {
				key = (String) var12.next();
				velocityContext.put(key, assocRecordData.get(key));
			}

			var12 = recordDataValue.keySet().iterator();

			while (var12.hasNext()) {
				key = (String) var12.next();
				velocityContext.put(key, recordDataValue.get(key));
			}

			requestTemplate.merge(velocityContext, requestPayloadWriter);
			log.debug("==================Saving Payload======================");
			log.debug(requestPayloadWriter.toString());
			log.debug("======================================================");
			this.requestPayload = requestPayloadWriter.toString();
			File dataFile = new File(new File(integrationParameters.getOutputDir()),
					String.format(integrationParameters.getOutputFileName(), new Date()));
			FileUtils.write(dataFile, this.requestPayload, StandardCharsets.UTF_8.name());
			returnMessage = String.format("%s\t%db\t%tc", dataFile.getAbsolutePath(), dataFile.length(),
					dataFile.lastModified());
			log.debug(returnMessage);
		} catch (IOException var13) {
			log.error(var13.getMessage(), var13);
		}

		return returnMessage;
	}

	public static void main(String[] args) throws FileNotFoundException, IOException {
		StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
		encryptor.setPassword("df390031-fa40-41ed-9951-dce21680a7a2");
		Properties props = new EncryptableProperties(encryptor);
		File propsFile = new File("sample-config/config.properties");
		props.load(new FileInputStream(propsFile));
		BOPropertiesReader boPropertiesReader = new BOPropertiesReader(props);
		HashMap<String, BOConfig> boConfigMap = boPropertiesReader.loadBOParameters(new File("sample-config"));
		System.out.println(String.format("%s\t%db\t%3$tY%3$tm%3$td", propsFile.getAbsolutePath(), propsFile.length(),
				propsFile.lastModified()));
		System.out.printf("PO_INV_%1$tY%1$tm%1$td_%1$tH_%1$tM.txt", System.currentTimeMillis());
		new FileTransferCustomTask();
		(new FileRequestHandler()).handleRequest((BOConfig) boConfigMap.get("cstCapitalProjectOutboundDTO"),
				"vtlCreate", new RecordData());
	}
}