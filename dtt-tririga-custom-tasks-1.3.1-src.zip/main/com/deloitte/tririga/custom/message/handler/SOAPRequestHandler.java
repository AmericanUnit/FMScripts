package com.deloitte.tririga.custom.message.handler;

import com.deloitte.tririga.custom.connection.IntegrationParameters;
import com.deloitte.tririga.custom.message.RecordData;
import com.deloitte.tririga.custom.message.handler.util.EpochDateTool;
import com.deloitte.tririga.custom.props.BOConfig;
import com.deloitte.tririga.custom.props.BOPropertiesReader;
import com.deloitte.tririga.logger.CustomLogger;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.StringWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.log4j.Logger;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.tools.generic.EscapeTool;
import org.apache.velocity.tools.generic.MathTool;
import org.apache.velocity.tools.generic.NumberTool;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.jasypt.properties.EncryptableProperties;

public class SOAPRequestHandler extends AbstractRequestHandler {
	private static final Logger log = CustomLogger.getCustomLogger().getDBLogger("SOAPRequestHandler");
	private static final String ERROR_MESSAGE_TEMPLATE = "<error><timestamp>%1$tc</timestamp><message>%3$s</message><recordId>%2$s</recordId></error>";
	private HttpClientContext localContext;

	public SOAPRequestHandler() {
		BasicCookieStore cookieStore = new BasicCookieStore();
		this.localContext = HttpClientContext.create();
		this.localContext.setCookieStore(cookieStore);
	}

	public String handleRequest(BOConfig boConfig, String paramName, RecordData recordData) {
		StringBuffer responseStringBuffer = new StringBuffer("");
		SSLContext sslContext = null;
		Object var6 = null;

		try {
			IntegrationParameters integrationParameters = boConfig.getIntegrationParameters();
			String httpsURL = (String) integrationParameters.getUrlMap().get(paramName);
			log.info("Posting to:" + httpsURL);
			StringWriter requestPayloadWriter = new StringWriter();
			VelocityContext velocityContext = new VelocityContext();
			velocityContext.put("dateTool", new EpochDateTool());
			velocityContext.put("esc", new EscapeTool());
			velocityContext.put("math", new MathTool());
			velocityContext.put("numberTool", new NumberTool());
			Template requestTemplate = velocityEngine
					.getTemplate((String) integrationParameters.getTemplateMap().get(paramName));
			HashMap<String, String> recordDataValue = recordData.getRecordData();
			Iterator var14 = recordDataValue.keySet().iterator();

			while (var14.hasNext()) {
				String key = (String) var14.next();
				velocityContext.put(key, recordDataValue.get(key));
			}

			HashMap<String, List<RecordData>> assocRecordData = recordData.getAssociatedRecords();
			Iterator var15 = assocRecordData.keySet().iterator();

			Iterator var18;
			String key;
			while (var15.hasNext()) {
				key = (String) var15.next();
				List<HashMap<String, String>> associatedRecordDataListMap = new ArrayList();
				var18 = ((List) assocRecordData.get(key)).iterator();

				while (var18.hasNext()) {
					RecordData eachAssocRecordData = (RecordData) var18.next();
					associatedRecordDataListMap.add(eachAssocRecordData.getRecordData());
				}

				velocityContext.put(key, associatedRecordDataListMap);
			}

			var15 = recordDataValue.keySet().iterator();

			while (var15.hasNext()) {
				key = (String) var15.next();
				velocityContext.put(key, recordDataValue.get(key));
			}

			requestTemplate.merge(velocityContext, requestPayloadWriter);
			this.requestPayload = requestPayloadWriter.toString();
			log.info("requestPayload:" + this.requestPayload);
			HashMap<String, String> httpHeaderMap = integrationParameters.getHTTPHeaders();
			URL url = new URL(httpsURL);
			HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
			HttpsURLConnection.setDefaultHostnameVerifier((hostName, sslSession) -> {
				return true;
			});
			if (httpHeaderMap != null) {
				var18 = httpHeaderMap.keySet().iterator();

				while (var18.hasNext()) {
					String key = (String) var18.next();
					conn.setRequestProperty(key, (String) httpHeaderMap.get(key));
				}
			}

			conn.setRequestProperty("Content-Type", integrationParameters.getContentType());
			conn.setDoOutput(true);
			BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(conn.getOutputStream()));
			bw.write(this.requestPayload);
			bw.close();
			InputStream is = conn.getResponseCode() >= 200 && conn.getResponseCode() < 300
					? conn.getInputStream()
					: conn.getErrorStream();
			if (is == null) {
				return responseStringBuffer.toString();
			}

			StringBuffer inputStreamBuffer = new StringBuffer();
			InputStreamReader isr = new InputStreamReader(is);
			BufferedReader br = new BufferedReader(isr);

			String inputLine;
			while ((inputLine = br.readLine()) != null) {
				inputStreamBuffer.append(inputLine);
			}

			if (conn.getResponseCode() > 300) {
				responseStringBuffer.append(String.format(
						"<error><timestamp>%1$tc</timestamp><message>%3$s</message><recordId>%2$s</recordId></error>",
						System.currentTimeMillis(), recordData.getRecordID(), inputStreamBuffer.toString()));
			} else {
				responseStringBuffer.append(inputStreamBuffer.toString());
			}

			log.info(conn.getResponseCode() + "-" + responseStringBuffer);
		} catch (Throwable var23) {
			responseStringBuffer.append(String.format(
					"<error><timestamp>%1$tc</timestamp><message>%3$s</message><recordId>%2$s</recordId></error>",
					System.currentTimeMillis(), recordData.getRecordID(), var23.toString()));
			log.error(var23.getMessage(), var23);
			StackTraceElement[] var12;
			int var11 = (var12 = var23.getStackTrace()).length;

			for (int var10 = 0; var10 < var11; ++var10) {
				StackTraceElement st = var12[var10];
				log.error(st.toString());
			}
		}

		return responseStringBuffer.toString();
	}

	public static void main(String[] args) throws FileNotFoundException, IOException {
		System.out.println(String.format(
				"<error><timestamp>%1$tc</timestamp><message>%3$s</message><recordId>%2$s</recordId></error>",
				System.currentTimeMillis(), 99999L, "null"));
		StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
		encryptor.setPassword("df390031-fa40-41ed-9951-dce21680a7a2");
		Properties props = new EncryptableProperties(encryptor);
		props.load(new FileInputStream("sample-config/config.properties"));
		BOPropertiesReader boPropertiesReader = new BOPropertiesReader(props);
		boPropertiesReader.loadBOParameters(new File("sample-config"));
		velocityEngine = new VelocityEngine();
		velocityEngine.setProperty("file.resource.loader.path", (new File("sample-config")).getAbsolutePath());
		velocityEngine.init();
		VelocityContext velocityContext = new VelocityContext();
		velocityContext.put("dateTool", new EpochDateTool());
		velocityContext.put("esc", new EscapeTool());
		Calendar calendar = Calendar.getInstance();
		calendar.set(1985, 4, 7);
		velocityContext.put("triProjectDescriptionTX", "xml chars < > / : &");
		velocityContext.put("cstScheduledStartDateDA", String.valueOf(calendar.getTimeInMillis()));
		Template requestTemplate = velocityEngine.getTemplate("ProjectCreate.vtl");
		StringWriter requestPayloadWriter = new StringWriter();
		requestTemplate.merge(velocityContext, requestPayloadWriter);
		System.out.println(requestPayloadWriter);
		boPropertiesReader.loadBOParameters(new File("sample-config"));
	}
}