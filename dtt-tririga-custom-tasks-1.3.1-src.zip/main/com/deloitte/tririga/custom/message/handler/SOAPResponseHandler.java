package com.deloitte.tririga.custom.message.handler;

import com.deloitte.tririga.custom.message.RecordData;
import com.deloitte.tririga.custom.props.Association;
import com.deloitte.tririga.custom.props.BOConfig;
import com.deloitte.tririga.custom.props.Association.ResponseMapping;
import com.deloitte.tririga.logger.CustomLogger;
import java.io.IOException;
import java.io.StringReader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.function.Consumer;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class SOAPResponseHandler implements ResponseHandler {
	private DocumentBuilder builder = null;
	private static final Logger log = CustomLogger.getCustomLogger().getDBLogger("SOAPResponseHandler");

	public SOAPResponseHandler() {
		try {
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			this.builder = documentBuilderFactory.newDocumentBuilder();
		} catch (ParserConfigurationException var2) {
			log.error(var2);
		}

	}

	public RecordData handleResponse(RecordData parentRecord, String paramName, BOConfig boConfig,
			String responsePayload) {
		HashMap<String, String> mappingElements = (HashMap) boConfig.getResponseSelectorMap().get(paramName);
		if (mappingElements == null) {
			mappingElements = new HashMap();
		}

		RecordData parentRecordToSave = new RecordData();
		HashMap<String, String> parentRecordDataMap = new HashMap();
		parentRecordToSave.setModule(parentRecord.getModule());
		parentRecordToSave.setObjectType(parentRecord.getObjectType());
		parentRecordToSave.setRecordID(parentRecord.getRecordID());
		parentRecordToSave.setModule(parentRecord.getModule());
		if (responsePayload == null) {
			return parentRecordToSave;
		} else {
			try {
				Document document = this.builder.parse(new InputSource(new StringReader(responsePayload)));
				XPathFactory pathFactory = XPathFactory.newInstance();
				XPath xPath = pathFactory.newXPath();
				mappingElements.entrySet().stream().forEach((element) -> {
					try {
						XPathExpression expression = xPath.compile((String) element.getValue());
						Node node = (Node) expression.evaluate(document, XPathConstants.NODE);
						if (node != null) {
							parentRecordDataMap.put((String) element.getKey(), node.getTextContent());
						}
					} catch (XPathExpressionException var10) {
						log.error(var10.getMessage());
						StackTraceElement[] var9;
						int var8 = (var9 = var10.getStackTrace()).length;

						for (int var7 = 0; var7 < var8; ++var7) {
							StackTraceElement st = var9[var7];
							log.error(st.toString());
						}
					}

				});
				parentRecordToSave.setRecordData(parentRecordDataMap);
				HashMap<String, List<RecordData>> inputAssocRecordMap = parentRecord.getAssociatedRecords();
				Iterator var13 = boConfig.getAssocList().iterator();

				while (var13.hasNext()) {
					Association assoc = (Association) var13.next();
					ResponseMapping responseMapping = (ResponseMapping) assoc.getResponseMapping().get(paramName);
					HashMap<String, RecordData> idBasedRecordDataMap = new HashMap();
					List<RecordData> assocDataList = (List) inputAssocRecordMap.get(assoc.getName());
					List<RecordData> assocDataToSaveList = new LinkedList();
					parentRecordToSave.getAssociatedRecords().put(assoc.getName(), assocDataToSaveList);
					Iterator var19 = assocDataList.iterator();

					while (var19.hasNext()) {
						RecordData r = (RecordData) var19.next();
						RecordData newRecordData = new RecordData();
						newRecordData.setModule(r.getModule());
						newRecordData.setObjectType(r.getObjectType());
						newRecordData.setRecordID(r.getRecordID());
						newRecordData.setModule(r.getModule());
						assocDataToSaveList.add(newRecordData);
						idBasedRecordDataMap.put((String) r.getRecordData().get(assoc.getId()), newRecordData);
					}

					XPathExpression expression = xPath.compile(responseMapping.getNodeListXpath());
					Node assocRootNode = (Node) expression.evaluate(document, XPathConstants.NODE);
					idBasedRecordDataMap.entrySet().stream().forEach((inputRecord) -> {
						try {
							String lookupExpr = responseMapping.getIdXpath().replace("$id",
									(CharSequence) inputRecord.getKey());
							XPathExpression idLookupExpression = xPath.compile(lookupExpr);
							Node nodeToParse = (Node) idLookupExpression.evaluate(assocRootNode, XPathConstants.NODE);
							HashMap<String, String> attrMap = responseMapping.getAttributeMap();
							attrMap.entrySet().stream().forEach((attr) -> {
								try {
									XPathExpression attrExpression = xPath.compile((String) attr.getValue());
									Node node = (Node) attrExpression.evaluate(nodeToParse, XPathConstants.NODE);
									if (node != null) {
										((RecordData) inputRecord.getValue()).getRecordData()
												.put((String) attr.getKey(), node.getTextContent());
									} else {
										log.warn("Could not find vaue for:" + (String) attr.getValue());
									}
								} catch (XPathExpressionException var9) {
									log.error(var9.getMessage());
									StackTraceElement[] var8;
									int var7 = (var8 = var9.getStackTrace()).length;

									for (int var6 = 0; var6 < var7; ++var6) {
										StackTraceElement element = var8[var6];
										log.error(element.toString());
									}
								}

							});
						} catch (XPathExpressionException var9) {
							log.error(var9.getMessage());
							StackTraceElement[] var8;
							int var7 = (var8 = var9.getStackTrace()).length;

							for (int var6 = 0; var6 < var7; ++var6) {
								StackTraceElement st = var8[var6];
								log.error(st.toString());
							}
						}

					});
				}
			} catch (IOException | XPathExpressionException | SAXException var21) {
				log.error(var21.getMessage());
				StackTraceElement[] var12;
				int var11 = (var12 = var21.getStackTrace()).length;

				for (int var10 = 0; var10 < var11; ++var10) {
					StackTraceElement st = var12[var10];
					log.error(st.toString());
				}
			}

			return parentRecordToSave;
		}
	}

	public static void main(String[] args) throws XPathExpressionException, SAXException, IOException {
		Document document = (new SOAPResponseHandler()).builder.parse(new InputSource(new StringReader(
				"<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"><soap:Header/><soap:Body><ns0:MT_ReceiveGRFeedsResponse xmlns:ns0=\"http://www.verizon.com/S2P/S4HANA/ReceiveGRFeeds\"><GR_RETHEADER><REF_GR_ID>1000001834</REF_GR_ID></GR_RETHEADER><GR_RETURNTABLE><MATERIAL_DOC_NUM>1000001834</MATERIAL_DOC_NUM><GR_LIN_NUM>10</GR_LIN_NUM><STATUS_IND>S</STATUS_IND></GR_RETURNTABLE></ns0:MT_ReceiveGRFeedsResponse></soap:Body></soap:Envelope>")));
		XPathFactory pathFactory = XPathFactory.newInstance();
		XPath xPath = pathFactory.newXPath();
		XPathExpression expression = xPath.compile("//*[local-name()='MT_ReceiveGRFeedsResponse']");
		Node l = (Node) expression.evaluate(document, XPathConstants.NODE);
		expression = xPath.compile("./GR_RETURNTABLE[GR_LIN_NUM[text()='10']]");
		Node lookupNode = (Node) expression.evaluate(l, XPathConstants.NODE);
		System.out.println(lookupNode.getTextContent());
		expression = xPath.compile("./MATERIAL_DOC_NUM");
		Node node = (Node) expression.evaluate(lookupNode, XPathConstants.NODE);
		if (node != null) {
			System.out.println(node.getTextContent());
		}

	}
}