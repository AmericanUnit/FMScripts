package com.deloitte.tririga.custom;

import com.tririga.pub.workflow.CustomTask;
import com.tririga.pub.workflow.Record;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.StringTokenizer;
import javax.naming.InitialContext;
import javax.sql.DataSource;
import org.apache.log4j.Logger;

public class SoftDeleteCustomTask implements CustomTask {
	private static final Logger log = Logger.getLogger(SoftDeleteCustomTask.class);

	public boolean execute(Record[] args) {
		log.info("SoftDeleteCustomTask BEGIN");
		Connection connection = null;

		try {
			connection = this.getConnection();
		} catch (SQLException var13) {
			var13.printStackTrace();
		}

		if (connection == null) {
			log.info("connection NULL");
			log.info("SoftDeleteCustomTask END");
			return false;
		} else {
			Record[] var6 = args;
			int var5 = args.length;

			for (int var4 = 0; var4 < var5; ++var4) {
				Record record = var6[var4];
				String tableName = this.getTableName(args[0].getRecordId(), connection);
				log.info(String.format("ID[%s],RecordID[%s]", record.getId(), record.getRecordId()));

				try {
					String tableUpdateStatement = String.format(
							"UPDATE %s SET SYS_OBJECTID = -SPEC_ID, SYS_OBJECTSTATE = NULL WHERE SPEC_ID = ?",
							tableName);
					String ibsSpecUpdateStatement = "UPDATE IBS_SPEC SET OBJECT_ID = -SPEC_ID, OBJECT_STATE = NULL, SYSTEM_STATE = 3, UPDATED_DATE = SYSDATE  -  2 WHERE SPEC_ID = ?";
					PreparedStatement preparedStatement = connection.prepareStatement(tableUpdateStatement);
					preparedStatement.setLong(1, record.getId());
					log.info(preparedStatement.executeQuery());
					preparedStatement.close();
					preparedStatement = connection.prepareStatement(ibsSpecUpdateStatement);
					preparedStatement.setLong(1, record.getId());
					log.info(preparedStatement.executeQuery());
					preparedStatement.close();
				} catch (SQLException var12) {
					var12.printStackTrace();
				}
			}

			try {
				connection.close();
			} catch (SQLException var11) {
				var11.printStackTrace();
			}

			log.info("SoftDeleteCustomTask END");
			return true;
		}
	}

	private Connection getConnection() throws SQLException {
		Connection connection = null;

		try {
			InitialContext context = new InitialContext();
			DataSource ds = (DataSource) context.lookup("jdbc/local/DataSource-TRIRIGA-data");
			connection = ds.getConnection();
		} catch (Exception var4) {
			log.error("Context Lookup Failed" + var4.getMessage());
		}

		return connection;
	}

	private String getTableName(long specId, Connection connection) {
		String query = "";

		try {
			PreparedStatement preparedStatement = connection.prepareStatement(
					"SELECT TABLE_NAME FROM OBJECT_MAP_HDR WHERE BO_ID = (SELECT SPEC_TEMPLATE_ID FROM IBS_SPEC WHERE SPEC_ID = ?)");
			preparedStatement.setLong(1, specId);
			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				query = resultSet.getString(1);
			}

			preparedStatement.close();
		} catch (SQLException var7) {
			log.error(var7);
		}

		return query;
	}

	public static void main(String[] args) throws Exception {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		StringTokenizer tokenizer = new StringTokenizer("adsadasd; dsadasd; dsad", ";");

		while (tokenizer.hasMoreTokens()) {
			String queryToExecute = tokenizer.nextToken();
			System.out.println(queryToExecute);
		}

		SoftDeleteCustomTask auditLogCustomTask = new SoftDeleteCustomTask();
		Record record = new Record(129210737L);
		auditLogCustomTask.execute(new Record[]{record});
		Connection connection = auditLogCustomTask.getConnection();
		connection.close();
	}
}