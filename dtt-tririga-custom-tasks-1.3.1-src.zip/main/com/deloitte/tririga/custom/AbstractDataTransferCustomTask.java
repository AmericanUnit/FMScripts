package com.deloitte.tririga.custom;

import com.deloitte.tririga.custom.message.RecordData;
import com.deloitte.tririga.custom.props.BOConfig;
import com.deloitte.tririga.custom.props.BOPropertiesReader;
import com.tririga.app.PropertiesService;
import com.tririga.app.PropertiesServiceImpl;
import com.tririga.pub.workflow.CustomParamBusinessConnectTask;
import com.tririga.pub.workflow.CustomParamTaskResult;
import com.tririga.pub.workflow.Record;
import com.tririga.ws.TririgaWS;
import com.tririga.ws.dto.Field;
import com.tririga.ws.dto.IntegrationRecord;
import com.tririga.ws.dto.Section;
import com.tririga.ws.dto.content.Content;
import com.tririga.ws.errors.InvalidArgumentException;
import com.tririga.ws.errors.ObjectTypeDoesNotExistException;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.function.Consumer;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

public abstract class AbstractDataTransferCustomTask implements CustomParamBusinessConnectTask {
	private static final Logger log = Logger.getLogger(AbstractDataTransferCustomTask.class);
	protected static final String REQUEST_CONTENT_FIELD_NAME = "cstRequestBI";
	protected static final String RESPONSE_CONTENT_FIELD_NAME = "cstResponseBI";
	public static File CLASS_LOADER_RESOURCE_ROOT;
	public static File CLASS_LOADER_JARFILE_ROOT;
	protected static HashMap<String, HashMap<String, HashSet<String>>> boAttributeMap = new HashMap();
	protected static HashMap<String, BOConfig> boConfigMap = new HashMap();
	protected static Properties baseProps = null;

	public AbstractDataTransferCustomTask() {
		init();
	}

	private static void init() {
		if (baseProps == null) {
			baseProps = new Properties();
			Properties classLoaderProps = new Properties();

			try {
				String classLoaderPropString = Util.getFailSafeResourceAsText("class-loader.properties", "\n");
				classLoaderProps.load(new ByteArrayInputStream(classLoaderPropString.getBytes()));
				PropertiesService service = PropertiesServiceImpl.getInstance();
				String configDir = "";
				String jarDir = "";
				String rootDir = null;
				if (service != null) {
					rootDir = service.getProperty(service.getWebPropertiesIdentifier(), "FileSystemRoot");
				}

				rootDir = rootDir == null ? "." : rootDir;
				configDir = System.getProperty("runInIDE") == null
						? classLoaderProps.getProperty("resourceDir")
						: "./sample-config/";
				jarDir = System.getProperty("runInIDE") == null ? classLoaderProps.getProperty("jarDir") : "./bin";
				CLASS_LOADER_RESOURCE_ROOT = new File(rootDir, configDir);
				CLASS_LOADER_JARFILE_ROOT = new File(rootDir, jarDir);
				baseProps.load(new FileInputStream(new File(CLASS_LOADER_RESOURCE_ROOT, "config.properties")));
			} catch (FileNotFoundException var6) {
				var6.printStackTrace();
			} catch (IOException var7) {
				var7.printStackTrace();
			}

			BOPropertiesReader boPropertiesReader = new BOPropertiesReader(baseProps);
			boConfigMap = boPropertiesReader.loadBOParameters(CLASS_LOADER_RESOURCE_ROOT);
		}
	}

	public abstract CustomParamTaskResult execute(TririgaWS var1, Map var2, long var3, Record[] var5);

	protected HashMap<String, HashSet<String>> updateObjectTypeMap(com.tririga.ws.dto.Record record,
			TririgaWS tririgaWS) throws ObjectTypeDoesNotExistException, InvalidArgumentException, Exception {
		Section[] sections = tririgaWS.getObjectType(record.getObjectTypeId()).getSections();
		HashMap<String, HashSet<String>> attributeMap = new HashMap();
		Section[] var8 = sections;
		int var7 = sections.length;

		for (int var6 = 0; var6 < var7; ++var6) {
			Section section = var8[var6];
			Field[] fields = section.getFields();
			HashSet<String> fieldSet = new HashSet();
			Field[] var14 = fields;
			int var13 = fields.length;

			for (int var12 = 0; var12 < var13; ++var12) {
				Field field = var14[var12];
				if (!field.getType().equals("Binary")) {
					fieldSet.add(field.getName());
				}
			}

			attributeMap.put(section.getName(), fieldSet);
		}

		log.info(record.getObjectTypeName() + ": Updated with:" + attributeMap);
		boAttributeMap.put(record.getObjectTypeName(), attributeMap);
		return attributeMap;
	}

	protected void savePayloadData(TririgaWS tririgaWS, RecordData recordData, String requestPayload,
			String responsePayload) {
		try {
			File requestTempFile = File.createTempFile("request", ".txt");
			FileUtils.writeStringToFile(requestTempFile, requestPayload);
			Content requestContent = new Content();
			DataSource requestDataSource = new FileDataSource(requestTempFile);
			requestContent.setContent(new DataHandler(requestDataSource));
			requestContent.setRecordId(recordData.getRecordID());
			requestContent.setFieldName("cstRequestBI");
			requestContent.setFileName("cstRequestBI.request.txt");
			tririgaWS.upload(requestContent);
			if (!responsePayload.isEmpty()) {
				File responseTempFile = File.createTempFile("response", ".txt");
				FileUtils.writeStringToFile(responseTempFile, responsePayload);
				DataSource responseDataSource = new FileDataSource(responseTempFile);
				Content responseContent = new Content();
				responseContent.setContent(new DataHandler(responseDataSource));
				responseContent.setRecordId(recordData.getRecordID());
				responseContent.setFieldName("cstResponseBI");
				responseContent.setFileName("cstResponseBI.response.txt");
				tririgaWS.upload(responseContent);
				FileUtils.forceDelete(responseTempFile);
			}

			FileUtils.forceDelete(requestTempFile);
			List<IntegrationRecord> intRecords = new LinkedList();
			intRecords.add(recordData.getIntegrationRecord(tririgaWS, (String) null));
			recordData.getAssociatedRecords().entrySet().stream().forEach((inputRecord) -> {
				Iterator var4 = ((List) inputRecord.getValue()).iterator();

				while (var4.hasNext()) {
					RecordData eachRecord = (RecordData) var4.next();

					try {
						intRecords.add(eachRecord.getIntegrationRecord(tririgaWS, (String) null));
					} catch (Exception var6) {
						log.error("Error Occurred:" + var6.getMessage());
					}
				}

			});
			tririgaWS.saveRecord((IntegrationRecord[]) intRecords.toArray(new IntegrationRecord[0]));
			log.debug("Uploaded REQ/RESP");
		} catch (Exception var11) {
			log.error("Error Occurred:" + var11.getMessage());
			StackTraceElement[] var9;
			int var8 = (var9 = var11.getStackTrace()).length;

			for (int var7 = 0; var7 < var8; ++var7) {
				StackTraceElement element = var9[var7];
				log.error(element.toString() + '\n');
			}
		}

	}

	public static File getRootDir() {
		if (CLASS_LOADER_RESOURCE_ROOT == null) {
			init();
		}

		return CLASS_LOADER_RESOURCE_ROOT;
	}
}