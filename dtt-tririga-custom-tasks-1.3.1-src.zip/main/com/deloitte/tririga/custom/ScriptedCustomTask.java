package com.deloitte.tririga.custom;

import com.deloitte.tririga.custom.message.RecordData;
import com.deloitte.tririga.custom.props.BOConfig;
import com.deloitte.tririga.logger.CustomLogger;
import com.tririga.pub.workflow.CustomParamTaskResult;
import com.tririga.pub.workflow.Record;
import com.tririga.ws.TririgaWS;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import org.apache.commons.csv.CSVFormat;
import org.apache.log4j.Logger;
import org.apache.log4j.NDC;

public class ScriptedCustomTask extends AbstractDataTransferCustomTask {
	private static final Logger log = CustomLogger.getCustomLogger().getDBLogger("ScriptedCustomTask");
	private static HashMap<String, HashMap<String, Object>> appContext = new HashMap();
	private static Boolean initialized = null;
	private static URL[] classLoaderURLs;

	private static void initScriptEngine() {
		try {
			log.info("Adding files from :" + CLASS_LOADER_JARFILE_ROOT.toURI().toURL());
			File[] jarFiles = CLASS_LOADER_JARFILE_ROOT.listFiles();
			classLoaderURLs = new URL[jarFiles.length + 1];

			for (int i = 0; i < jarFiles.length; ++i) {
				classLoaderURLs[i] = jarFiles[i].toURI().toURL();
			}

			classLoaderURLs[jarFiles.length] = CLASS_LOADER_RESOURCE_ROOT.toURI().toURL();
			log.info("Script Engine Initiliazed");
		} catch (Exception var5) {
			log.error(var5.getMessage());
			StackTraceElement[] var4;
			int var3 = (var4 = var5.getStackTrace()).length;

			for (int var2 = 0; var2 < var3; ++var2) {
				StackTraceElement element = var4[var2];
				log.error(element.toString());
			}

			initialized = false;
		}

		if (initialized == null) {
			initialized = true;
		}

	}

	public synchronized CustomParamTaskResult execute(TririgaWS tririgaWS, Map paramMap, long userID,
			Record[] recordArray) {
		if (initialized == null) {
			initScriptEngine();
		} else if (!initialized) {
			log.error("Error initializing the classloader - please refer to the stack trace");
		}

		int var8;
		StackTraceElement[] records;
		try {
			NDC.push(String.valueOf(userID));
			Record[] var17 = recordArray;
			var8 = recordArray.length;

			for (int var16 = 0; var16 < var8; ++var16) {
				Record record = var17[var16];
				records = null;
				RecordData recordData = new RecordData();
				com.tririga.ws.dto.Record[] records = tririgaWS.getRecordDataHeaders(new long[]{record.getId()});
				HashMap<String, HashSet<String>> attributeMap = (HashMap) boAttributeMap
						.get(records[0].getObjectTypeName());
				BOConfig boConfig = (BOConfig) boConfigMap.get(records[0].getObjectTypeName());
				if (attributeMap == null) {
					attributeMap = this.updateObjectTypeMap(records[0], tririgaWS);
				}

				recordData.setRecordID(record.getId());
				recordData.setObjectType(records[0].getObjectTypeName());
				recordData.setAttributes(attributeMap);
				recordData.setModule(boConfig.getModule());
				recordData.fillRecordData(tririgaWS, boConfig);
				if (paramMap != null) {
					Set<String> keySet = paramMap.keySet();
					keySet.forEach((scriptParam) -> {
						String scriptFile = (String) boConfig.getScriptFileNameMap().get(scriptParam);
						if (scriptFile == null) {
							log.error("Could not find script for:" + scriptParam);
						} else {
							try {
								log.info("Executing:" + scriptFile);
								ClassLoader currentThreadClassLoader = Thread.currentThread().getContextClassLoader();
								URLClassLoader urlClassLoader = new URLClassLoader(classLoaderURLs,
										currentThreadClassLoader);
								Thread.currentThread().setContextClassLoader(urlClassLoader);
								ScriptEngine engine = (new ScriptEngineManager()).getEngineByName("JavaScript");
								NDC.push("" + record.getId());
								engine.put("appContext", appContext);
								engine.put("inputRecordArray", recordArray);
								engine.put("recordData", recordData);
								engine.put("boConfig", boConfig);
								engine.put("tririgaWS", tririgaWS);
								engine.put("userID", userID);
								engine.put("triDS", Util.getTriDataSource());
								engine.put("classLoader", urlClassLoader);
								engine.put("logger", CustomLogger.getCustomLogger());
								engine.eval(Util.getFailSafeResourceAsText(scriptFile, "\n"));
								NDC.pop();
								log.info("Execution Complete");
							} catch (ScriptException var12) {
								log.error(var12.getMessage());
								Iterator var11 = Arrays.asList(var12.getStackTrace()).subList(0, 11).iterator();

								while (var11.hasNext()) {
									StackTraceElement element = (StackTraceElement) var11.next();
									log.error(element.toString());
								}
							}

						}
					});
				}
			}
		} catch (Exception var15) {
			log.error(var15.getMessage());
			int var9 = (records = var15.getStackTrace()).length;

			for (var8 = 0; var8 < var9; ++var8) {
				StackTraceElement element = records[var8];
				log.error(element.toString());
			}
		}

		NDC.remove();
		return new CustomParamTaskResult() {
			public Map getReturnParameters() {
				return null;
			}

			public boolean getExecutionWasSuccessful() {
				return true;
			}
		};
	}

	public static void main(String[] args)
			throws FileNotFoundException, ScriptException, MalformedURLException, ClassNotFoundException {
		new URLClassLoader(new URL[]{(new File(
				"C:\\Users\\kavadlakonda\\Documents\\GitHub\\Repositories\\dtt-tririga-custom-tasks\\build\\libs\\dtt-tririga-custom-tasks-dependencies-1.2.jar"))
				.toURI().toURL()}, (ClassLoader) null);
		ScriptEngineManager manager = new ScriptEngineManager();
		ScriptEngine engine = manager.getEngineByName("JavaScript");
		RecordData r = new RecordData();
		engine.put("recordData", r);
		engine.put("inFileFormat", CSVFormat.TDF.withRecordSeparator("\n").withAllowMissingColumnNames());
		engine.put("outFileFormat", CSVFormat.EXCEL.withRecordSeparator('\n').withAllowMissingColumnNames());
		engine.eval(new FileReader("./sample-config/test.js.txt"));
		System.out.println(r.getRecordID());
		System.lineSeparator();
	}
}