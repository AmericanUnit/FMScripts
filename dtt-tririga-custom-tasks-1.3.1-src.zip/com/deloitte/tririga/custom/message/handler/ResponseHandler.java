package com.deloitte.tririga.custom.message.handler;

import com.deloitte.tririga.custom.message.RecordData;
import com.deloitte.tririga.custom.props.BOConfig;

public interface ResponseHandler {
	RecordData handleResponse(RecordData var1, String var2, BOConfig var3, String var4);
}