package com.deloitte.tririga.custom.message.handler.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.log4j.Logger;

public class EpochDateTool {
	private static final Logger log = Logger.getLogger(EpochDateTool.class);

	public String format(String format, String millisecondsElapsed) {
		log.debug("format:" + format + "_" + millisecondsElapsed);
		String returnValue = null;

		try {
			returnValue = (new SimpleDateFormat(format)).format(new Date(Long.parseLong(millisecondsElapsed)));
		} catch (Exception var5) {
			var5.printStackTrace();
			log.error(var5.getMessage(), var5);
		}

		return returnValue;
	}

	public String currentTime(String format) {
		long millisecondsElapsed = System.currentTimeMillis();
		log.debug("format:" + format + "@" + millisecondsElapsed);
		String returnValue = null;

		try {
			returnValue = (new SimpleDateFormat(format)).format(new Date(millisecondsElapsed));
		} catch (Exception var6) {
			var6.printStackTrace();
			log.error(var6.getMessage(), var6);
		}

		return returnValue;
	}

	public Date toDate(String millisecondsElapsed) {
		log.debug("millisecondsElapsed:" + millisecondsElapsed);
		Date returnValue = null;

		try {
			returnValue = new Date(Long.parseLong(millisecondsElapsed));
		} catch (Exception var4) {
			var4.printStackTrace();
			log.error(var4.getMessage(), var4);
		}

		return returnValue;
	}
}