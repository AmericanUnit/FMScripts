package com.deloitte.tririga.custom.message.handler;

import com.deloitte.tririga.custom.message.RecordData;
import com.deloitte.tririga.custom.props.BOConfig;

public interface RequestHandler {
	String handleRequest(BOConfig var1, String var2, RecordData var3);

	String getRequestSubmitted();
}