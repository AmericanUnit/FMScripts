package com.deloitte.tririga.custom.message.handler.mapper;

import com.deloitte.tririga.custom.message.RecordData;

public class XpathMapper implements Mapper {
	public RecordData mapMessage(String message, MappingElement element) {
		return null;
	}
}