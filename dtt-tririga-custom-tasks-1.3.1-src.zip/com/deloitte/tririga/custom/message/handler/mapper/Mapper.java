package com.deloitte.tririga.custom.message.handler.mapper;

import com.deloitte.tririga.custom.message.RecordData;

public interface Mapper {
	RecordData mapMessage(String var1, MappingElement var2);
}