package com.deloitte.tririga.custom.message.handler.mapper;

public class MappingElement {
	private String attributeName;
	private String selector;
	private String sectionName;
	private String boName;

	public String getAttributeName() {
		return this.attributeName;
	}

	public void setAttributeName(String attributeName) {
		this.attributeName = attributeName;
	}

	public String getSelector() {
		return this.selector;
	}

	public void setSelector(String selector) {
		this.selector = selector;
	}

	public String getSectionName() {
		return this.sectionName;
	}

	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}

	public String getBoName() {
		return this.boName;
	}

	public void setBoName(String boName) {
		this.boName = boName;
	}
}