package com.deloitte.tririga.custom.message.handler;

import com.deloitte.tririga.custom.AbstractDataTransferCustomTask;
import com.deloitte.tririga.custom.message.RecordData;
import com.deloitte.tririga.custom.props.BOConfig;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.runtime.resource.loader.FileResourceLoader;

public abstract class AbstractRequestHandler implements RequestHandler {
	protected static final String VLT_EPOCH = "dateTool";
	protected static final String VLT_ESC = "esc";
	protected static final String VLT_MATH = "math";
	protected static final String VLT_NUMBER = "numberTool";
	protected String requestPayload;
	protected static VelocityEngine velocityEngine;

	public String getRequestSubmitted() {
		return this.requestPayload;
	}

	public void setRequestPayload(String requestPayload) {
		this.requestPayload = requestPayload;
	}

	protected AbstractRequestHandler() {
		velocityEngine = new VelocityEngine();
		velocityEngine.setProperty("file.resource.loader.class", FileResourceLoader.class.getName());
		velocityEngine.setProperty("file.resource.loader.path",
				AbstractDataTransferCustomTask.CLASS_LOADER_RESOURCE_ROOT.getAbsolutePath());
		velocityEngine.init();
	}

	public abstract String handleRequest(BOConfig var1, String var2, RecordData var3);
}