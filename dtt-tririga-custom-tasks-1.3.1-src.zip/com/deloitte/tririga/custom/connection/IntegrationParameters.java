package com.deloitte.tririga.custom.connection;

import java.security.KeyStore;
import java.security.Provider;
import java.security.Security;
import java.util.HashMap;
import javax.net.ssl.SSLContext;
import org.apache.log4j.Logger;

public class IntegrationParameters {
	private static final Logger log = Logger.getLogger(IntegrationParameters.class);
	private static HashMap<String, SSLContext> sslContextMap = new HashMap();
	private String boName;
	private HashMap<String, String> urlMap;
	private String method;
	private String contentType;
	private HashMap<String, String> templateMap;
	private KeyStore keyStore;
	private String keystorePassword;
	private KeyStore trustStore;
	private String trustStorePassword = "changeit";
	private String outputFileName;
	private String outputDir;
	private HashMap<String, String> httpHeaders;
	private static Boolean initialized;

	private static void init() {
		log.info("Initiliazing");
		Provider[] providers = Security.getProviders();
		initialized = true;
		log.info("Initiliaztion complete");
	}

	public HashMap<String, String> getUrlMap() {
		return this.urlMap;
	}

	public void setUrlMap(HashMap<String, String> url) {
		this.urlMap = url;
	}

	public String getMethod() {
		return this.method;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public String getContentType() {
		return this.contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public HashMap<String, String> getTemplateMap() {
		return this.templateMap;
	}

	public void setTemplateMap(HashMap<String, String> template) {
		this.templateMap = template;
	}

	public KeyStore getKeyStore() {
		return this.keyStore;
	}

	public void setKeyStore(KeyStore keyStore) {
		this.keyStore = keyStore;
	}

	public String getKeystorePassword() {
		return this.keystorePassword;
	}

	public void setKeystorePassword(String keystorePassword) {
		this.keystorePassword = keystorePassword;
	}

	public KeyStore getTrustStore() {
		return this.trustStore;
	}

	public String getTrustStorePassword() {
		return this.trustStorePassword;
	}

	public void setTrustStore(KeyStore trustStore) {
		this.trustStore = trustStore;
	}

	public void setTrustStorePassword(String trustStorePassword) {
		this.trustStorePassword = trustStorePassword;
	}

	public String getBoName() {
		return this.boName;
	}

	public void setBoName(String boName) {
		this.boName = boName;
	}

	public String getOutputFileName() {
		return this.outputFileName;
	}

	public void setOutputFileName(String outputFileName) {
		this.outputFileName = outputFileName;
	}

	public String getOutputDir() {
		return this.outputDir;
	}

	public void setOutputDir(String outputDir) {
		this.outputDir = outputDir;
	}

	public HashMap<String, String> getHTTPHeaders() {
		return this.httpHeaders;
	}

	public void setHTTPHeaders(HashMap<String, String> httpHeaders) {
		this.httpHeaders = httpHeaders;
	}
}