package com.deloitte.tririga.custom;

import com.deloitte.tririga.custom.converter.DelimitedFileFormatConverter;
import com.deloitte.tririga.custom.converter.FileFormatConverter;
import com.deloitte.tririga.custom.file.FileDiff;
import com.deloitte.tririga.custom.file.FileDiffConfig;
import com.deloitte.tririga.custom.file.FileDiffImpl;
import com.deloitte.tririga.custom.message.RecordData;
import com.deloitte.tririga.custom.props.BOConfig;
import com.github.difflib.algorithm.DiffException;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.tririga.pub.workflow.CustomBusinessConnectTask;
import com.tririga.pub.workflow.Record;
import com.tririga.ws.TririgaWS;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import org.apache.log4j.Logger;

public class FixedWidthConverterCustomTask implements CustomBusinessConnectTask {
	private static final Logger log = Logger.getLogger(FixedWidthConverterCustomTask.class);
	protected static Properties baseProps;
	private static HashMap<String, FileDiffConfig> fixedWidthMap = new HashMap();

	public FixedWidthConverterCustomTask() {
		baseProps = new Properties();

		try {
			File classLoaderRoot = AbstractDataTransferCustomTask.getRootDir();
			baseProps.load(new FileInputStream(new File(classLoaderRoot, "file-diff-config.properties")));
			Gson gson = new Gson();
			Type associationlistType = (new TypeToken<List<FileDiffConfig>>() {
			}).getType();
			List<FileDiffConfig> mappingList = (List) gson.fromJson(baseProps.getProperty("fileMapping"),
					associationlistType);
			Iterator var5 = mappingList.iterator();

			while (var5.hasNext()) {
				FileDiffConfig c = (FileDiffConfig) var5.next();
				fixedWidthMap.put(c.getName(), c);
			}
		} catch (FileNotFoundException var7) {
			var7.printStackTrace();
		} catch (IOException var8) {
			var8.printStackTrace();
		}

	}

	public static void main(String[] args) throws IOException, DiffException {
		new FixedWidthConverterCustomTask();
		System.out.println(baseProps);
		String ioName = "cstSAPVendorInboundDTO - File - Inbound - LFA1";
		File workingDir = new File(baseProps.get("source-dir").toString());
		FileDiff diffImpl = new FileDiffImpl();
		FileDiffConfig diffConfig = (FileDiffConfig) fixedWidthMap.get(ioName);
		diffImpl.diffFile(workingDir, diffConfig);
		FileFormatConverter converter = new DelimitedFileFormatConverter();
		converter.convert(workingDir, diffConfig);
	}

	public boolean execute(TririgaWS tririgaWS, long userId, Record[] args) {
		log.info("FixedWidthConverterCustomTask BEGIN");
		Record[] var5 = args;
		int var6 = args.length;
		int var7 = 0;

		while (var7 < var6) {
			Record record = var5[var7];
			com.tririga.ws.dto.Record[] records = null;
			RecordData recordData = new RecordData();

			try {
				records = tririgaWS.getRecordDataHeaders(new long[]{record.getId()});
				log.info(String.format("ID[%s],ObjectTypeName[%s], Temp Token[%s]", record.getId(),
						records[0].getObjectTypeName(), record.getTempToken()));
				HashMap<String, HashSet<String>> attributeMap = new HashMap();
				HashSet<String> t = new HashSet();
				t.add("triNameTX");
				attributeMap.put("General", t);
				recordData.setModule("triIntegration");
				recordData.setRecordID(record.getId());
				recordData.setObjectType(records[0].getObjectTypeName());
				recordData.setAttributes(attributeMap);
				recordData.fillRecordData(tririgaWS, (BOConfig) null);
				String ioName = (String) recordData.getRecordData().get("triNameTX");
				File workingDir = new File(baseProps.get("source-dir").toString());
				FileDiff diffImpl = new FileDiffImpl();
				FileDiffConfig diffConfig = (FileDiffConfig) fixedWidthMap.get(ioName);
				diffImpl.diffFile(workingDir, diffConfig);
				FileFormatConverter converter = new DelimitedFileFormatConverter();
				converter.convert(workingDir, diffConfig);
				return true;
			} catch (Exception var18) {
				log.error("Error Occurred:" + var18.getMessage());
				log.error(var18.getClass().toString() + ", Caused by:" + var18.getCause());
				StackTraceElement[] var12 = var18.getStackTrace();
				int var13 = var12.length;

				for (int var14 = 0; var14 < var13; ++var14) {
					StackTraceElement element = var12[var14];
					log.error(element.toString() + '\n');
				}

				++var7;
			}
		}

		log.info("FixedWidthConverterCustomTask END");
		return true;
	}
}