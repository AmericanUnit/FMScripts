package com.deloitte.tririga.custom.converter;

import com.deloitte.tririga.custom.file.FileDiffConfig;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

public interface FileFormatConverter {
	boolean convert(File var1, FileDiffConfig var2) throws FileNotFoundException, IOException;
}