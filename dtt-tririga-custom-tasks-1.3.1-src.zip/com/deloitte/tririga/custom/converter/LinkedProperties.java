package com.deloitte.tririga.custom.converter;

import java.util.Collections;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Properties;

class LinkedProperties extends Properties {
	private final HashSet<Object> keys = new LinkedHashSet();

	public Iterable<Object> orderedKeys() {
		return Collections.list(this.keys());
	}

	public Enumeration<Object> keys() {
		return Collections.enumeration(this.keys);
	}

	public Object put(Object key, Object value) {
		this.keys.add(key);
		return super.put(key, value);
	}
}