package com.deloitte.tririga.custom.file;

public class FileDiffConfig {
	private String name;
	private String sourceFileNamePattern;
	private String targetFileName;
	private String fixedWidthConfigProperties;
	private char delimiter;

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSourceFileNamePattern() {
		return this.sourceFileNamePattern;
	}

	public void setSourceFileNamePattern(String sourceFileNamePattern) {
		this.sourceFileNamePattern = sourceFileNamePattern;
	}

	public String getTargetFileName() {
		return this.targetFileName;
	}

	public void setTargetFileName(String targetFileName) {
		this.targetFileName = targetFileName;
	}

	public String getFixedWidthConfigProperties() {
		return this.fixedWidthConfigProperties;
	}

	public void setFixedWidthConfigProperties(String fixedWidthConfigProperties) {
		this.fixedWidthConfigProperties = fixedWidthConfigProperties;
	}

	public char getDelimiter() {
		return this.delimiter;
	}

	public void setDelimiter(char delimiter) {
		this.delimiter = delimiter;
	}
}