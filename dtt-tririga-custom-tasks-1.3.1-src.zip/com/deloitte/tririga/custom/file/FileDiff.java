package com.deloitte.tririga.custom.file;

import java.io.File;
import java.io.IOException;

public interface FileDiff {
	boolean diffFile(File var1, FileDiffConfig var2) throws IOException;
}