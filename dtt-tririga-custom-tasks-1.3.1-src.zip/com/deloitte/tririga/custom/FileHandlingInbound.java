package com.deloitte.tririga.custom;

import com.deloitte.tririga.custom.message.RecordData;
import com.deloitte.tririga.custom.props.BOConfig;
import com.tririga.pub.workflow.CustomParamTaskResult;
import com.tririga.pub.workflow.Record;
import com.tririga.ws.TririgaWS;
import com.tririga.ws.dto.IntegrationField;
import com.tririga.ws.dto.IntegrationRecord;
import com.tririga.ws.dto.IntegrationSection;
import com.tririga.ws.dto.gui.GUI;
import java.io.File;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import org.apache.log4j.Logger;

public class FileHandlingInbound extends AbstractDataTransferCustomTask {
	boolean processStatus = false;
	static Logger logger = Logger.getLogger(FileHandlingInbound.class);

	public CustomParamTaskResult execute(TririgaWS tririgaWS, Map params, long userId, Record[] args) {
		logger.info("FileHandlingCustomTask BEGIN");
		Record[] var6 = args;
		int var7 = args.length;

		for (int var8 = 0; var8 < var7; ++var8) {
			Record record = var6[var8];
			com.tririga.ws.dto.Record[] records = null;
			RecordData recordData = new RecordData();

			try {
				records = tririgaWS.getRecordDataHeaders(new long[]{record.getId()});
				logger.debug(String.format("ID[%s],ObjectTypeName[%s], Temp Token[%s]", record.getId(),
						records[0].getObjectTypeName(), record.getTempToken()));
				HashMap<String, HashSet<String>> attributeMap = (HashMap) boAttributeMap
						.get(records[0].getObjectTypeName());
				BOConfig boConfig = (BOConfig) boConfigMap.get(records[0].getObjectTypeName());
				if (attributeMap == null) {
					attributeMap = this.updateObjectTypeMap(records[0], tririgaWS);
				}

				logger.debug("Details printed here --->" + record.getId() + " --- " + records[0].getObjectTypeName()
						+ " --- " + attributeMap + " --- " + baseProps.getProperty("base-module"));
				recordData.setRecordID(record.getId());
				recordData.setObjectType(records[0].getObjectTypeName());
				recordData.setAttributes(attributeMap);
				recordData.setModule("triIntegration");
				recordData.fillRecordData(tririgaWS, boConfig);
				logger.debug("Setup completed");
				HashMap<String, String> attributes = recordData.getRecordData();
				String IO_NAME = (String) attributes.get("triNameTX");
				String FILE_PATH = (String) attributes.get("triFilePathTX");
				logger.debug("Retrvd data " + IO_NAME + "---" + FILE_PATH);
				File folder = new File(FILE_PATH);
				File[] listOfFiles = folder.listFiles();

				for (int i = 0; i < listOfFiles.length; ++i) {
					if (listOfFiles[i].isFile()) {
						String fName = listOfFiles[i].getName();
						long lastModified = listOfFiles[i].lastModified();
						long fileSize = listOfFiles[i].length();
						this.callTririga(tririgaWS, IO_NAME, fName, fileSize, lastModified);
					} else if (listOfFiles[i].isDirectory()) {
						System.out.println("Directory " + listOfFiles[i].getName());
						logger.debug("Directory " + listOfFiles[i].getName());
					}
				}
			} catch (Exception var25) {
				StackTraceElement[] var13 = var25.getStackTrace();
				int var14 = var13.length;

				for (int var15 = 0; var15 < var14; ++var15) {
					StackTraceElement element = var13[var15];
					logger.error(element.toString() + '\n');
				}
			}
		}

		logger.info("FileHandlingCustomTask END");
		return new CustomParamTaskResult() {
			public Map getReturnParameters() {
				return null;
			}

			public boolean getExecutionWasSuccessful() {
				return true;
			}
		};
	}

	public void callTririga(TririgaWS ws, String ioName, String fileName, long fileSize, long lastModified) {
		try {
			IntegrationRecord iRecord = new IntegrationRecord();
			iRecord.setModuleId(ws.getModuleId("triHelper"));
			iRecord.setObjectTypeId(ws.getObjectTypeId("triHelper", "triCalculationHelper"));
			GUI[] GUIs = ws.getGUIsByName("triCalculationHelper", "triHelper");
			GUI[] var10 = GUIs;
			int var11 = GUIs.length;

			for (int var12 = 0; var12 < var11; ++var12) {
				GUI gui = var10[var12];
				if ("triCalculationHelper".equals(gui.getName())) {
					iRecord.setGuiId(gui.getId());
					break;
				}
			}

			iRecord.setObjectTypeName("triCalculationHelper");
			iRecord.setId(-1L);
			iRecord.setActionName("triCalculate");
			IntegrationSection[] integrationSection = new IntegrationSection[]{new IntegrationSection()};
			integrationSection[0].setName("triGeneral");
			IntegrationField integrationField_1 = new IntegrationField();
			integrationField_1.setName("triInput1TX");
			integrationField_1.setValue(fileName);
			IntegrationField integrationField_2 = new IntegrationField();
			integrationField_2.setName("triInput2TX");
			integrationField_2.setValue(ioName);
			IntegrationField integrationField_3 = new IntegrationField();
			integrationField_3.setName("triInput4TX");
			integrationField_3.setValue("Active");
			IntegrationField integrationField_4 = new IntegrationField();
			integrationField_4.setName("triInput1DA");
			integrationField_4.setValue(lastModified + "");
			IntegrationField integrationField_5 = new IntegrationField();
			integrationField_5.setName("triInput1NU");
			integrationField_5.setValue(fileSize + "");
			IntegrationField[] integrationFieldArray = new IntegrationField[]{integrationField_1, integrationField_2,
					integrationField_3, integrationField_4, integrationField_5};
			integrationSection[0].setFields(integrationFieldArray);
			iRecord.setSections(integrationSection);
			ws.saveRecord(new IntegrationRecord[]{iRecord});
		} catch (Exception var17) {
			logger.error(var17);
			logger.error("Error TRI:", var17);
		}

	}
}