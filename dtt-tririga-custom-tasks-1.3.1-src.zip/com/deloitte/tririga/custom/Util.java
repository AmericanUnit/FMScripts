package com.deloitte.tririga.custom;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.naming.InitialContext;
import javax.sql.DataSource;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import org.apache.log4j.Logger;

public class Util {
	public static final char NEW_LINE = '\n';
	private static final Logger log = Logger.getLogger(Util.class);
	public static final char FILE_EXTENSION_DELIMITER = '.';

	public static String getResourceAsText(String file, String lineSeparator) throws IOException {
		StringBuffer buff = new StringBuffer();
		BufferedReader br = new BufferedReader(
				new InputStreamReader(Util.class.getClassLoader().getResourceAsStream(file)));
		String eachLine = "";

		while ((eachLine = br.readLine()) != null) {
			if (!eachLine.trim().startsWith("--")) {
				buff.append(eachLine);
				buff.append(lineSeparator);
			}
		}

		return buff.toString();
	}

	public static String formatXMLString(String unformattedXML) throws TransformerException {
		Transformer t = TransformerFactory.newInstance().newTransformer();
		t.setOutputProperty("indent", "yes");
		t.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
		Writer out = new StringWriter();
		t.transform(new StreamSource(new StringReader(unformattedXML)), new StreamResult(out));
		return out.toString();
	}

	public static String getFailSafeResourceAsText(String file, String lineSeparator) {
		try {
			return getResourceAsText(file, lineSeparator);
		} catch (IOException var3) {
			var3.printStackTrace();
			return "";
		}
	}

	public static String getAttribute(Connection conn, long recordId, String fieldName, String objectType)
			throws SQLException {
		log.debug(String.format("recordId[%s], fieldName[%s], objectType[%s]", recordId, fieldName, objectType));
		String atrValue = "";
		PreparedStatement preparedStatement = conn.prepareStatement(
				"SELECT TABLE_NAME, COLUMN_NAME FROM OBJECT_FIELD_MAP WHERE  ELEMENT_TYPE = 'B' AND ATR_NAME = ? AND BO_ID = (SELECT SPEC_TEMPLATE_ID FROM IBS_SPEC WHERE SPEC_ID = ?)");
		preparedStatement.setString(1, fieldName);
		preparedStatement.setLong(2, recordId);
		ResultSet resultSet = preparedStatement.executeQuery();
		String tableName = "T_" + objectType;
		if (resultSet.next()) {
			tableName = resultSet.getString("TABLE_NAME");
			fieldName = resultSet.getString("COLUMN_NAME");
		}

		resultSet.close();
		preparedStatement.close();
		String query = String.format("SELECT %s FROM %s WHERE SPEC_ID = ?", fieldName, tableName);
		log.debug(String.format("query[%s]", query));
		preparedStatement = conn.prepareStatement(query);
		preparedStatement.setLong(1, recordId);
		resultSet = preparedStatement.executeQuery();
		if (resultSet.next()) {
			atrValue = resultSet.getString(fieldName);
		}

		resultSet.close();
		preparedStatement.close();
		log.debug(String.format("atrValue[%s]", atrValue));
		return atrValue;
	}

	public static DataSource getTriDataSource() {
		try {
			InitialContext context = new InitialContext();
			DataSource ds = (DataSource) context.lookup("jdbc/local/DataSource-TRIRIGA-data");
			return ds;
		} catch (Exception var2) {
			log.error("Context Lookup Failed" + var2.getMessage());
			return null;
		}
	}
}