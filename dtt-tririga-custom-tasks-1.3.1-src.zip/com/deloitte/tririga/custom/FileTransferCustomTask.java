package com.deloitte.tririga.custom;

import com.deloitte.tririga.custom.message.RecordData;
import com.deloitte.tririga.custom.message.handler.FileRequestHandler;
import com.deloitte.tririga.custom.message.handler.RequestHandler;
import com.deloitte.tririga.custom.props.BOConfig;
import com.tririga.pub.workflow.CustomParamTaskResult;
import com.tririga.pub.workflow.Record;
import com.tririga.ws.TririgaWS;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.apache.log4j.Logger;

public class FileTransferCustomTask extends AbstractDataTransferCustomTask {
	private static final Logger log = Logger.getLogger(FileTransferCustomTask.class);

	public CustomParamTaskResult execute(TririgaWS tririgaWS, Map params, long userId, Record[] args) {
		log.info("FileTransferCustomTask BEGIN");
		String firstParam = "";
		if (params != null) {
			log.debug("params:" + params);
			Set keySet = params.keySet();
			firstParam = keySet == null ? "" : (String) keySet.toArray()[0];
		}

		Record[] var21 = args;
		int var8 = args.length;

		for (int var9 = 0; var9 < var8; ++var9) {
			Record record = var21[var9];
			com.tririga.ws.dto.Record[] records = null;
			RecordData recordData = new RecordData();
			StringBuffer responseBuffer = new StringBuffer();
			String requestPayload = "";

			try {
				records = tririgaWS.getRecordDataHeaders(new long[]{record.getId()});
				log.info(String.format("ID[%s],ObjectTypeName[%s], Temp Token[%s]", record.getId(),
						records[0].getObjectTypeName(), record.getTempToken()));
				HashMap<String, HashSet<String>> attributeMap = (HashMap) boAttributeMap
						.get(records[0].getObjectTypeName());
				BOConfig boConfig = (BOConfig) boConfigMap.get(records[0].getObjectTypeName());
				if (attributeMap == null) {
					attributeMap = this.updateObjectTypeMap(records[0], tririgaWS);
				}

				recordData.setRecordID(record.getId());
				recordData.setObjectType(records[0].getObjectTypeName());
				recordData.setAttributes(attributeMap);
				recordData.setModule(boConfig.getModule());
				recordData.fillRecordData(tririgaWS, boConfig);
				RequestHandler requestHandler = new FileRequestHandler();
				String reponsePayload = requestHandler.handleRequest(boConfig, firstParam, recordData);
				requestPayload = requestHandler.getRequestSubmitted();
				responseBuffer.append(reponsePayload);
			} catch (Exception var20) {
				responseBuffer.append(var20.getMessage());
				StackTraceElement[] var16 = var20.getStackTrace();
				int var17 = var16.length;

				for (int var18 = 0; var18 < var17; ++var18) {
					StackTraceElement element = var16[var18];
					responseBuffer.append(element.toString() + '\n');
				}
			}

			this.savePayloadData(tririgaWS, recordData, requestPayload, responseBuffer.toString());
		}

		log.info("FileTransferCustomTask END");
		return new CustomParamTaskResult() {
			public Map getReturnParameters() {
				return null;
			}

			public boolean getExecutionWasSuccessful() {
				return true;
			}
		};
	}
}