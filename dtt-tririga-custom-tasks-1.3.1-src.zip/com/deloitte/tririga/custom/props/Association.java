package com.deloitte.tririga.custom.props;

import java.util.HashMap;

public class Association {
	private String name;
	private String string;
	private String module;
	private String bo;
	private String id;
	private HashMap<String, Association.ResponseMapping> responseMapping;

	public HashMap<String, Association.ResponseMapping> getResponseMapping() {
		return this.responseMapping;
	}

	public void setResponseMapping(HashMap<String, Association.ResponseMapping> responseMapping) {
		this.responseMapping = responseMapping;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getString() {
		return this.string;
	}

	public void setString(String string) {
		this.string = string;
	}

	public String getModule() {
		return this.module;
	}

	public void setModule(String module) {
		this.module = module;
	}

	public String getBo() {
		return this.bo;
	}

	public void setBo(String bo) {
		this.bo = bo;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public class ResponseMapping {
		String nodeListXPath;
		String idXPath;
		HashMap<String, String> attributeMap;

		public String getNodeListXpath() {
			return this.nodeListXPath;
		}

		public void setNodeListXpath(String nodeListXPath) {
			this.nodeListXPath = nodeListXPath;
		}

		public String getIdXpath() {
			return this.idXPath;
		}

		public void setIdXpath(String idXPath) {
			this.idXPath = idXPath;
		}

		public HashMap<String, String> getAttributeMap() {
			return this.attributeMap;
		}

		public void setAttributeMap(HashMap<String, String> attributeMap) {
			this.attributeMap = attributeMap;
		}
	}
}