package com.deloitte.tririga.custom.props;

import com.deloitte.tririga.custom.connection.IntegrationParameters;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import org.apache.log4j.Logger;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.jasypt.properties.EncryptableProperties;

public class BOPropertiesReader {
	private static final Logger log = Logger.getLogger(BOPropertiesReader.class);
	private static final String BO = "bo.";
	private static final char DOT = '.';
	private Properties baseProperties;

	public BOPropertiesReader(Properties baseProperties) {
		this.baseProperties = baseProperties;
	}

	public HashMap<String, BOConfig> loadBOParameters(File resourceDir) {
		log.info("Loading properties from:" + resourceDir.getAbsolutePath());
		StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
		encryptor.setPassword("df390031-fa40-41ed-9951-dce21680a7a2");
		HashMap<String, BOConfig> boConfigMap = new HashMap();
		Gson gson = new Gson();
		Type associationlistType = (new TypeToken<List<Association>>() {
		}).getType();
		Type genericMapType = (new TypeToken<HashMap<String, String>>() {
		}).getType();
		Type responseSelectorMapType = (new TypeToken<HashMap<String, HashMap<String, String>>>() {
		}).getType();
		log.debug("Loading properties listed in:" + this.baseProperties);

		try {
			Iterator var8 = this.baseProperties.stringPropertyNames().iterator();

			while (var8.hasNext()) {
				String prop = (String) var8.next();
				if (prop.startsWith("bo.")) {
					String moduleName = prop.substring("bo.".length(), prop.lastIndexOf(46));
					String boName = prop.substring(prop.lastIndexOf(46) + 1);
					BOConfig boConfig = new BOConfig(boConfigMap);
					boConfig.setObjectTypeName(boName);
					boConfig.setModule(moduleName);
					InputStream inStream = new FileInputStream(
							new File(resourceDir, this.baseProperties.getProperty(prop)));
					Properties boProperties = new EncryptableProperties(encryptor);
					boProperties.load(inStream);
					log.info("Loaded:" + this.baseProperties.getProperty(prop));
					log.debug(boProperties);
					IntegrationParameters integrationParameters = new IntegrationParameters();
					integrationParameters.setContentType(boProperties.getProperty("contentType"));
					String urlMap = boProperties.getProperty("url");
					integrationParameters.setUrlMap((HashMap) gson.fromJson(urlMap, genericMapType));
					integrationParameters.setMethod(boProperties.getProperty("method"));
					String templateString = boProperties.getProperty("template");
					integrationParameters.setTemplateMap((HashMap) gson.fromJson(templateString, genericMapType));
					String httpHeaders = boProperties.getProperty("http-headers");
					if (httpHeaders != null) {
						integrationParameters.setHTTPHeaders((HashMap) gson.fromJson(httpHeaders, genericMapType));
					}

					integrationParameters.setOutputFileName(boProperties.getProperty("outputFileName"));
					integrationParameters.setOutputDir(boProperties.getProperty("outputDir"));
					boConfig.setIntegrationParameters(integrationParameters);
					String associations = boProperties.getProperty("associations");
					String responseSelectorMapStr = boProperties.getProperty("responseSelectorMap");
					List<Association> associationList = (List) gson.fromJson(associations, associationlistType);
					HashMap<String, HashMap<String, String>> responseSelectorMap = (HashMap) gson
							.fromJson(responseSelectorMapStr, responseSelectorMapType);
					if (associationList != null) {
						boConfig.setAssocList(associationList);
					}

					if (responseSelectorMap != null) {
						boConfig.setResponseSelectorMap(responseSelectorMap);
					}

					String scriptFile = boProperties.getProperty("script");
					HashMap<String, String> scriptFileMap = (HashMap) gson.fromJson(scriptFile, genericMapType);
					boConfig.setScriptFileNameMap(scriptFileMap != null ? scriptFileMap : new HashMap());
					boConfigMap.put(boName, boConfig);
				}
			}
		} catch (IOException var25) {
			log.error("Error Occurred:" + var25.getMessage());
			StackTraceElement[] var9 = var25.getStackTrace();
			int var10 = var9.length;

			for (int var11 = 0; var11 < var10; ++var11) {
				StackTraceElement element = var9[var11];
				log.error(element.toString());
			}
		}

		return boConfigMap;
	}

	public static void main(String[] args) throws IOException {
		InputStream inStream = new FileInputStream("sample-config/config.properties");
		Properties props = new Properties();
		props.load(inStream);
		BOPropertiesReader boPropertiesReader = new BOPropertiesReader(props);
		boPropertiesReader.loadBOParameters(new File("sample-config"));
	}
}