package com.deloitte.tririga.custom.props;

import com.deloitte.tririga.custom.connection.IntegrationParameters;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

public class BOConfig {
	private long objectTypeId;
	private String objectTypeName;
	private String module;
	private HashMap<String, BOConfig> parentBOConfigMap = null;
	private HashMap<String, HashSet<String>> attributeMap = new HashMap();
	private List<Association> assocList = new ArrayList();
	private IntegrationParameters integrationParameters;
	private HashMap<String, HashMap<String, String>> responseSelectorMap;
	private HashMap<String, String> scriptFileNameMap;

	public BOConfig(HashMap<String, BOConfig> parentBOConfigMap) {
		this.parentBOConfigMap = parentBOConfigMap;
	}

	public HashMap<String, BOConfig> getParentBOConfigMap() {
		return this.parentBOConfigMap;
	}

	public List<Association> getAssocList() {
		return this.assocList;
	}

	public void setAssocList(List<Association> assocList) {
		this.assocList = assocList;
	}

	public String getObjectTypeName() {
		return this.objectTypeName;
	}

	public void setObjectTypeName(String objectTypeName) {
		this.objectTypeName = objectTypeName;
	}

	public void setObjectTypeId(long objectTypeId) {
		this.objectTypeId = objectTypeId;
	}

	public long getObjectTypeId() {
		return this.objectTypeId;
	}

	public HashMap<String, HashSet<String>> getAttributeMap() {
		return this.attributeMap;
	}

	public void setAttributeMap(HashMap<String, HashSet<String>> attributeMap) {
		this.attributeMap = attributeMap;
	}

	public IntegrationParameters getIntegrationParameters() {
		return this.integrationParameters;
	}

	public void setIntegrationParameters(IntegrationParameters integrationParameters) {
		this.integrationParameters = integrationParameters;
	}

	public HashMap<String, HashMap<String, String>> getResponseSelectorMap() {
		return this.responseSelectorMap;
	}

	public void setResponseSelectorMap(HashMap<String, HashMap<String, String>> responseSelectorMap) {
		this.responseSelectorMap = responseSelectorMap;
	}

	public HashMap<String, String> getScriptFileNameMap() {
		return this.scriptFileNameMap;
	}

	public void setScriptFileNameMap(HashMap<String, String> scriptFileNameMap) {
		this.scriptFileNameMap = scriptFileNameMap;
	}

	public String getModule() {
		return this.module;
	}

	public void setModule(String module) {
		this.module = module;
	}
}