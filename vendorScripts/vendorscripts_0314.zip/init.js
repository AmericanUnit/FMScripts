var request = apiWrapper.getHttpServletRequest();
var response = apiWrapper.getHttpServletResponse();
var tririgaWS = apiWrapper.getTririgaWS();

var USER_ACCOUNT_MAPPING = {

    "c131256-api": "C131256",
    "c120297-api": "C120297",
    "c122252-api": "C122252"
};