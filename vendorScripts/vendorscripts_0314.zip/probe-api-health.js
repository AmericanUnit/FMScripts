// Load compatibility script
load("nashorn:mozilla_compat.js");

importPackage(java.lang);
importPackage(java.util);
importPackage(java.text);



(
	function execute() {




	})();

