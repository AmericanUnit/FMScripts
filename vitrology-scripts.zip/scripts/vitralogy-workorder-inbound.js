load("nashorn:mozilla_compat.js");
load(classLoader.getResource("vitralogy-init.js"));


importPackage(org.json);
importPackage(java.io);
importPackage(java.util);

importPackage(com.tririga.ws.dto);
importPackage(com.tririga.ws.dto.content);

importPackage(javax.activation);
importPackage(com.deloitte.tririga.custom.message);

importPackage(java.nio.charset);
importPackage(javax.activation);

load(classLoader.getResource("vitralogy-workorder-inbound-create.js"));
load(classLoader.getResource("vitralogy-workorder-inbound-update-task.js"));
load(classLoader.getResource("vitralogy-workorder-inbound-update-remark.js"));
load(classLoader.getResource("vitralogy-workorder-inbound-change-request-status.js"));

(function execute(){

    var action = request.getParameter("action");

    if(action == null ) action = "";

    if(action.equalsIgnoreCase("newRequest"))
        executeCreate();
    else if(action.equalsIgnoreCase("updateRequest"))
        executeUpdate();
    else if(action.equalsIgnoreCase("updateRemark"))
        executeUpdateRemark();
   else if(action.equalsIgnoreCase("changeRequestStatus"))
        executeChangeRequestStatus();
    else{
		response.setHeader("Content-Type", "text/xml");
        response.getWriter().print("<version>vitralogy v1.0-"+new java.util.Date()+"</version>");
    }
        
})();


function saveRequestResponse(specID, requestXML, responseXML){
    

	var FileUtils = Java.type("org.apache.commons.io.FileUtils");
	var File = Java.type("java.io.File");
    

	var tmpFile = File.createTempFile("requestXML", ".txt");
	FileUtils.writeByteArrayToFile(tmpFile,requestXML.getBytes());

	var fileDS = new FileDataSource(tmpFile);
	var dataHandler = new DataHandler(fileDS);

	var content = new Content();
	content.setRecordId(specID);
	content.setContent(dataHandler);
	content.setFieldName("cstRequestBI");
	content.setFileName("requestXML.txt");

	var upload = tririgaWS.upload(content);
	tmpFile.delete();


	tmpFile = File.createTempFile("responseXML", ".txt");
	FileUtils.writeByteArrayToFile(tmpFile,responseXML.getBytes());

	var fileDS = new FileDataSource(tmpFile);
	var dataHandler = new DataHandler(fileDS);

	var content = new Content();
	content.setRecordId(specID);
	content.setContent(dataHandler);
	content.setFieldName("cstResponseBI");
	content.setFileName("responseXML.txt");

	var upload = tririgaWS.upload(content);
	tmpFile.delete();
}