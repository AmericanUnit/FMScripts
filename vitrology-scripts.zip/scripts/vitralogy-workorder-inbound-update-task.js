
function executeUpdate() {

	var log = logger.getDBLogger("vitrology-workorder-inbound-update-task-js-log");

	var inputStream = request.getInputStream();

	var inputRequestLength = request.getContentLength();

	if(inputRequestLength <= 0){
		log.info("Invalid request inputRequestLength:"+inputRequestLength);
		response.setHeader("Content-Type", "text/xml");
        response.getWriter().print("<version>vitrology v1.0-"+new java.util.Date()+"</version>");
		return;
    }

	var byteArr = Array(inputRequestLength);
	var requestXML =   request.getParameter("data");
	log.info("Request:"+requestXML);

	var root = null;

	try{
		root = JSON.parse(XML.toJSONObject(requestXML).toString());
	}catch(error){
		log.error("Error : " + error);
		var FMUtil = Java.type("com.deloitte.tririga.common.FMUtil")
		var responseXML = FMUtil.getResourceAsText("vitralogy-workorder-inbound-resp-template-error.xml");
		responseXML = java.lang.String.format(responseXML, org.apache.commons.lang.StringEscapeUtils.escapeXml("Unable to Parse Request XML!! Exception - " + error),400,0,0);
		log.info("Response:"+responseXML);
		response.getWriter().print(responseXML);
		response.setStatus(200);
		return;
	}

	var tranformMap = {
		General: {
			vVitralogyId: root.UpdateRequestDueDates.UpdateRequestDueDate.ExternalReference + "",
			workTaskId: root.UpdateRequestDueDates.UpdateRequestDueDate.TRIRIGAWorkTaskNum + "",
			description: root.UpdateRequestDueDates.UpdateRequestDueDate.RequestDescription + "",
			reason: root.UpdateRequestDueDates.UpdateRequestDueDate.Reason + "",
			date: root.UpdateRequestDueDates.UpdateRequestDueDate.CreatedDateTime + "",
			createdBy: root.UpdateRequestDueDates.UpdateRequestDueDate.CreatedBy + "",
			status: "Update Request"

		}
	};

	log.debug("tranformMap:"+JSON.stringify(tranformMap));

	log.info("workTaskId,vVitralogyId :" + tranformMap.General.workTaskId + "-" + tranformMap.General.vVitralogyId);

	var workTaskDTORecord = new RecordData();

	var attributeSet = new HashSet();

	attributeSet.addAll(["cstVitralogyIdTX",  "triDescriptionTX", "triCommentTX", "cstCreatedDateTimeTX", "triCreatedByTX", "cstStatusTX","triRecordIdSY"]);

	var attributeMap = new HashMap();

	attributeMap.put("General", attributeSet);

	workTaskDTORecord.setRecordID(-1);
	workTaskDTORecord.setObjectType("cstWorkTaskDTO");
	workTaskDTORecord.setAttributes(attributeMap);
	workTaskDTORecord.setModule("cstIntegration");

	log.info("About to pull data:" + tranformMap.General.workTaskId);

	workTaskDTORecord.fillRecordData(tririgaWS, "General", "cstWorkTaskIdTX", tranformMap.General.workTaskId);

	var recordDataMap = workTaskDTORecord.getRecordData();

	if (recordDataMap.get("triRecordIdSY") == null){
		log.info("Checking for Legacy Work Orders");
		workTaskDTORecord.fillRecordData(tririgaWS, "General", "triLegacyIDTX", tranformMap.General.workTaskId);
		recordDataMap = workTaskDTORecord.getRecordData();
	}

	if(recordDataMap.get("triRecordIdSY") == null){
		var FMUtil = Java.type("com.deloitte.tririga.common.FMUtil")
		var responseXML = FMUtil.getResourceAsText("vitralogy-workorder-inbound-resp-template-error.xml");
		responseXML = java.lang.String.format(responseXML, "Unable to find Work Order",404,tranformMap.General.vVitralogyId,tranformMap.General.workTaskId);
		log.info("Response:"+responseXML);
		response.getWriter().print(responseXML);
		response.setStatus(200);
		return;
	}
	
	workTaskDTORecord.setRecordID(recordDataMap.get("triRecordIdSY"));

	log.info("Record Id:" +recordDataMap.get("triRecordIdSY"));

	recordDataMap.put("cstVitralogyIdTX", tranformMap.General.vVitralogyId);
	//recordDataMap.put("cstVRepairAlarmBL", tranformMap.General.alarmClear);
	//recordDataMap.put("cstVRepairAlarmTX", tranformMap.General.alarmClear);
	recordDataMap.put("cstNotesTX", tranformMap.General.description);
	recordDataMap.put("triCommentTX", tranformMap.General.reason);
	recordDataMap.put("cstCreatedDateTimeTX", tranformMap.General.date);
	recordDataMap.put("triCreatedByTX", tranformMap.General.createdBy);
	recordDataMap.put("cstStatusTX", tranformMap.General.status);

	workTaskDTORecord.saveRecordData(tririgaWS, "cstUpdate");

	log.info(attributeMap);

	var FMUtil = Java.type("com.deloitte.tririga.common.FMUtil")

	var responseXML = FMUtil.getResourceAsText("vitralogy-workorder-inbound-resp-template.xml");


	responseXML = java.lang.String.format(responseXML, tranformMap.General.vVitralogyId, tranformMap.General.workTaskId);

	saveRequestResponse(recordDataMap.get("triRecordIdSY"), requestXML,responseXML);

	log.info("Response:"+responseXML);

	//response.setHeader("Content-Type", "text/xml");
	response.getWriter().print(responseXML);
}