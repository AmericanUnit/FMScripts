
function executeUpdateRemark() {

	var log = logger.getDBLogger("vitralogy-workorder-inbound-update-remark-js-log");

	var inputStream = request.getInputStream();



	var inputRequestLength = request.getContentLength();

	if(inputRequestLength <= 0){
		log.info("Invalid request inputRequestLength:"+inputRequestLength);
		response.setHeader("Content-Type", "text/xml");
        response.getWriter().print("<version>vitralogy v1.0-"+new java.util.Date()+"</version>");
		return;
    }

	var byteArr = Array(inputRequestLength);
	var requestXML =   request.getParameter("data");

	/*var xmlData = Java.to(byteArr, "byte[]");

	//Start reading XML Request as a Stream of Bytes
	var bis = new BufferedInputStream(inputStream);

	bis.read(xmlData, 0, xmlData.length);

	var xmlString = "";

	if (request.getCharacterEncoding() != null) {
		xmlString = new java.lang.String(xmlData, request.getCharacterEncoding());
	} else {
		xmlString = new java.lang.String(xmlData);
	}*/

	log.info("Request:"+requestXML);

	var root = null;

	try{
		root = JSON.parse(XML.toJSONObject(requestXML).toString());
	}catch(error){
		log.error("Error : " + error);
		var FMUtil = Java.type("com.deloitte.tririga.common.FMUtil")
		var responseXML = FMUtil.getResourceAsText("vitralogy-workorder-inbound-resp-template-error.xml");
		responseXML = java.lang.String.format(responseXML, org.apache.commons.lang.StringEscapeUtils.escapeXml("Unable to Parse Request XML!! Exception - " + error),400,0,0);
		log.info("Response:"+responseXML);
		response.getWriter().print(responseXML);
		response.setStatus(200);
		return;
	}
	var REMARK_MAP = {
		"REMARK": "RMK",
	};

	var tranformMap = {
		General: {
			vVitralogyId: root.UpdateRequestComments.comments.ExternalReference + "",
			workTaskId: root.UpdateRequestComments.comments.TRIRIGAWorkTaskNum + "",
			commentDate: root.UpdateRequestComments.comments.CommentDateTime + "",
			commentText: root.UpdateRequestComments.comments.CommentText + "",
			commentType: REMARK_MAP[root.UpdateRequestComments.comments.CommentType] + "",
			createdBy: root.UpdateRequestComments.comments.CreatedBy + "",
			status: "Update Remark"

		}
	};

	log.debug("tranformMap:"+JSON.stringify(tranformMap));

	log.info("workTaskId,vVitralogyId :" + tranformMap.General.workTaskId + "-" + tranformMap.General.vVitralogyId);

	var workTaskDTORecord = new RecordData();

	var attributeSet = new HashSet();

	attributeSet.addAll(["cstCommentDateTX","cstCommentTX","cstCommentTypeTX","cstCreatedByTX","cstStatusTX", "triRecordIdSY"]);

	var attributeMap = new HashMap();

	attributeMap.put("General", attributeSet);

	workTaskDTORecord.setRecordID(-1);
	workTaskDTORecord.setObjectType("cstWorkTaskDTO");
	workTaskDTORecord.setAttributes(attributeMap);
	workTaskDTORecord.setModule("cstIntegration");

	log.info("About to pull data:" + tranformMap.General.workTaskId);

	workTaskDTORecord.fillRecordData(tririgaWS, "General", "cstWorkTaskIdTX", tranformMap.General.workTaskId);
	var recordDataMap = workTaskDTORecord.getRecordData();

	
	if (recordDataMap.get("triRecordIdSY") == null){
		log.info("Checking for Legacy Work Orders");
		workTaskDTORecord.fillRecordData(tririgaWS, "General", "triLegacyIDTX", tranformMap.General.workTaskId);
		recordDataMap = workTaskDTORecord.getRecordData();
	}


	if(recordDataMap.get("triRecordIdSY") == null){
		var FMUtil = Java.type("com.deloitte.tririga.common.FMUtil")
		var responseXML = FMUtil.getResourceAsText("vitralogy-workorder-inbound-resp-template-error.xml");
		responseXML = java.lang.String.format(responseXML, "Unable to find Work Order",404,tranformMap.General.vVitralogyId,tranformMap.General.workTaskId);
		log.info("Response:"+responseXML);
		response.getWriter().print(responseXML);
		response.setStatus(200);
		return;
	}
	workTaskDTORecord.setRecordID(recordDataMap.get("triRecordIdSY"));

	log.info("Record Id:" +recordDataMap.get("triRecordIdSY"));

	recordDataMap.put("cstVitralogyIdTX", tranformMap.General.vVitralogyId);
	recordDataMap.put("cstCommentDateTX", tranformMap.General.commentDate);
	recordDataMap.put("cstCommentTX", tranformMap.General.commentText);
	recordDataMap.put("cstCommentTypeTX", tranformMap.General.commentType);
	recordDataMap.put("cstCreatedByTX", tranformMap.General.createdBy);
	recordDataMap.put("cstStatusTX", tranformMap.General.status);

	/*workTaskDTORecord.getRecordData().put("cstCommentDateTX", tranformMap.General.commentDate);
	workTaskDTORecord.getRecordData().put("cstCommentTX", tranformMap.General.commentText);
	workTaskDTORecord.getRecordData().put("cstCommentTypeTX", tranformMap.General.commentType);
	workTaskDTORecord.getRecordData().put("cstCreatedByTX", tranformMap.General.createdBy);
	workTaskDTORecord.getRecordData().put("cstStatusTX", tranformMap.General.status);*/

	workTaskDTORecord.saveRecordData(tririgaWS, "cstUpdate");

	log.info(attributeMap);

	var FMUtil = Java.type("com.deloitte.tririga.common.FMUtil")

	var responseXML = FMUtil.getResourceAsText("vitralogy-workorder-inbound-resp-template.xml");


	responseXML = java.lang.String.format(responseXML, tranformMap.General.vVitralogyId, tranformMap.General.workTaskId);



	saveRequestResponse(recordDataMap.get("triRecordIdSY"), requestXML,responseXML);
	log.info("Response:"+responseXML);

	//response.setHeader("Content-Type", "text/xml");
	response.getWriter().print(responseXML);
}