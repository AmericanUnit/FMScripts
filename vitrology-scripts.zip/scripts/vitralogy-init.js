var request = apiWrapper.getHttpServletRequest();
var response = apiWrapper.getHttpServletResponse();
var tririgaWS = apiWrapper.getTririgaWS();

