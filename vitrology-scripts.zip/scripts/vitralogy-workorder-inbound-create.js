importPackage(com.tririga.design.smartobjecttype.dataaccess);
importPackage(java.sql);

var log = logger.getDBLogger("vitralogy-workorder-inbound-create-js-log");

function executeCreate() {



	var inputStream = request.getInputStream();

	var inputRequestLength = request.getContentLength();
	
	if(inputRequestLength <= 0){
		log.info("Invalid request inputRequestLength:"+inputRequestLength);
		response.setHeader("Content-Type", "text/xml");
        response.getWriter().print("<version>Vitralogy v1.0-"+new java.util.Date()+"</version>");
		return;
    }

	var byteArr = Array(inputRequestLength);

	var requestXML = request.getParameter("data");

	log.info("Request:" + requestXML);

	var root = null;

	try{
		root = JSON.parse(XML.toJSONObject(requestXML).toString());
	}catch(error){
		log.error("Error : " + error);
		var FMUtil = Java.type("com.deloitte.tririga.common.FMUtil")
		var responseXML = FMUtil.getResourceAsText("vitralogy-workorder-inbound-resp-template-error.xml");
		responseXML = java.lang.String.format(responseXML, org.apache.commons.lang.StringEscapeUtils.escapeXml("Unable to Parse Request XML!! Exception - " + error),400,0,0);
		log.info("Response:"+responseXML);
		response.getWriter().print(responseXML);
		response.setStatus(200);
		return;
	}


	var tranformMap = {
		General: {
			cstVitralogyIdTX: root.NewRequest.WorkReq.Request.ExternalReference + "",
			triNameTX: root.NewRequest.WorkReq.Request.TaskName + "",
			cstVZIDTX: root.NewRequest.WorkReq.Request.RequesterName + "",
			cstPhoneForContactTX: root.NewRequest.WorkReq.Request.PhoneForContact + "",
			cstAssignedTX: root.NewRequest.WorkReq.Request.RequestDate + "",
			cstPlannedEndTX: root.NewRequest.WorkReq.Request.TargetCompletionDate + "",
			cstRequestClassTX: root.NewRequest.WorkReq.Request.RequestType + "",
			triIdTX: root.NewRequest.WorkReq.Request.SystemID + "",
			cstGroupNameTX: root.NewRequest.WorkReq.Request.GroupName + "",
			cstPriorityClassTX: "P" + root.NewRequest.WorkReq.Request.Priority + "",
			triDescriptionTX: root.NewRequest.WorkReq.Request.RequestDescription + "",
			cstProviderCodeTX: root.NewRequest.WorkReq.Request.ProviderCode + "",
			cstStatusTX: "New Request"

		}
	};

	var FMUtil = Java.type("com.deloitte.tririga.common.FMUtil")

	var responseXML = FMUtil.getResourceAsText("vitralogy-workorder-inbound-resp-template.xml");

	if (root.NewRequest.WorkReq.Request.SystemID == undefined || root.NewRequest.WorkReq.Request.SystemID == "") {
		responseXML = FMUtil.getResourceAsText("vitralogy-workorder-inbound-resp-template-error.xml");
		responseXML = java.lang.String.format(responseXML, "Rejecting request, missing location information", 400, tranformMap.General.cstVitralogyIdTX, -1);
		log.warn("Rejecting request, missing location information:"+root.NewRequest.WorkReq.Request.SystemID);
		log.info("Response:" + responseXML);
		response.getWriter().print(responseXML);
		response.setStatus(200);
		return;
	}

	if (executeSqlQuery("triBuilding",root.NewRequest.WorkReq.Request.SystemID,["SPEC_ID"]).length == 0) {
		responseXML = FMUtil.getResourceAsText("vitralogy-workorder-inbound-resp-template-error.xml");
		responseXML = java.lang.String.format(responseXML, "Rejecting request, Location not found in Tririga [" + root.NewRequest.WorkReq.Request.SystemID +"]", 400, tranformMap.General.cstVitralogyIdTX, -1);
		log.warn("Rejecting request, Location not found in Tririga : " + root.NewRequest.WorkReq.Request.SystemID);
		log.info("Response:" + responseXML);
		response.getWriter().print(responseXML);
		response.setStatus(200);
		return;
	}

	var reqTypeData = executeSqlQuery("triRequestClass", root.NewRequest.WorkReq.Request.RequestType,["TRIPATHTX"]);

	log.info("Request Class Query Data : " + reqTypeData);
	if (reqTypeData.length == 0 || reqTypeData[0].TRIPATHTX == null || !reqTypeData[0].TRIPATHTX.startsWith("\\Classifications\\Request Class\\VZ Request Class\\")){
		responseXML = FMUtil.getResourceAsText("vitralogy-workorder-inbound-resp-template-error.xml");
		responseXML = java.lang.String.format(responseXML, "Rejecting request, Request Class not found in Tririga [" + root.NewRequest.WorkReq.Request.RequestType + "]", 400, tranformMap.General.cstVitralogyIdTX, -1);
		log.warn("Rejecting request, Request Class not found in Tririga : " + root.NewRequest.WorkReq.Request.RequestType);
		log.info("Response:" + responseXML);
		response.getWriter().print(responseXML);
		response.setStatus(200);
		return;
	}

	responseXML = FMUtil.getResourceAsText("vitralogy-workorder-inbound-resp-template.xml");


	var dtoData = getWorkTaskDTO(tranformMap.General.cstVitralogyIdTX);
	log.info("Is DTO Present : " + dtoData);
	log.debug("tranformMap:" + JSON.stringify(tranformMap));

	var existingWorkTaskID = dtoData.get("cstWorkTaskIdTX")

	if (existingWorkTaskID == null) {
		log.info("Creating New DTO Record")
		var integrationRecordArray = [];

		var integrationRecord = new IntegrationRecord();
		integrationRecord.setModuleId(tririgaWS.getModuleId("cstIntegration"));
		integrationRecord.setObjectTypeId(tririgaWS.getObjectTypeId("cstIntegration", "cstWorkTaskDTO"));

		var integrationSection = new IntegrationSection();
		integrationSection.setName("General");

		var guis = tririgaWS.getGUIsByName("cstWorkTaskDTO", "cstIntegration");

		var triWorkTaskGuiId = "";

		for (var i = 0; i < guis.length; i++) {
			if (guis[i].getName().equals("cstWorkTaskDTO")) {
				triWorkTaskGuiId = guis[i].getId();
				integrationRecord.setGuiId(guis[i].getId());;
				break;
			}
		};

		var integrationFieldArray = [];

		integrationRecord.setObjectTypeName("cstWorkTaskDTO");
		integrationRecord.setId(-1);
		integrationRecord.setActionName("cstActive");

		Object.keys(tranformMap.General).forEach((function (col) {
			var integrationField = new IntegrationField();
			integrationField.setName(col);
			integrationField.setValue(tranformMap.General[col]);

			//log.debug("integrationField=>" + integrationField.getName() + ":" + integrationField.getValue())
			integrationFieldArray.push(integrationField);
		}));

		integrationSection.setFields(integrationFieldArray);

		var intSectionArray = [integrationSection];
		integrationRecord.setSections(intSectionArray);

		integrationRecordArray.push(integrationRecord);


		var triResponse = tririgaWS.saveRecord(integrationRecordArray)

		/*var integrationResponse = {
			//cstRecordsSuccessNU: triResponse.getSuccessful()+"",
			//cstRecordsFailNU: triResponse.getFailed()+"",
			//cstRecordsWarnNU: "0",
			//cstRecordsTotalNU: triResponse.getTotal()+"",
			spec_id: triResponse.getResponseHelpers()[0].getRecordId()
		};*/

		var workTaskDTORecord = new RecordData();

		var workTaskDTOAttributeSet = new HashSet();
		workTaskDTOAttributeSet.addAll(["cstWorkTaskIdTX", "triModifiedSY", "triRecordIdSY"]);

		var workTaskDTOAttributeMap = new HashMap();
		workTaskDTOAttributeMap.put("General", workTaskDTOAttributeSet);

		workTaskDTORecord.setRecordID(triResponse.getResponseHelpers()[0].getRecordId());
		workTaskDTORecord.setObjectType("cstWorkTaskDTO");
		workTaskDTORecord.setAttributes(workTaskDTOAttributeMap);
		workTaskDTORecord.setModule("cstIntegration");

		workTaskDTORecord.fillRecordData(tririgaWS, null);
		responseXML = java.lang.String.format(responseXML, tranformMap.General.cstVitralogyIdTX, workTaskDTORecord.getRecordData().get("cstWorkTaskIdTX"));
		saveRequestResponse(triResponse.getResponseHelpers()[0].getRecordId(), requestXML, responseXML);
	} else {
		log.info("Sending Old DTO Record : " + dtoData.get("triRecordIdSY"));
		responseXML = java.lang.String.format(responseXML, tranformMap.General.cstVitralogyIdTX, existingWorkTaskID);
		saveRequestResponse(dtoData.get("triRecordIdSY"), requestXML, responseXML);
	}

	log.info("Response:" + responseXML);

	//response.setHeader("Content-Type", "text/xml");
	response.getWriter().print(responseXML);
}

function getWorkTaskDTO(id) {

	try {
		var rd = new RecordData();

		var as = new HashSet();

		as.addAll(["cstVitralogyIdTX", "cstWorkTaskIdTX", "triRecordIdSY"]);

		var am = new HashMap();

		am.put("General", as);

		rd.setRecordID(-1);
		rd.setObjectType("cstWorkTaskDTO");
		rd.setAttributes(am);
		rd.setModule("cstIntegration");

		rd.fillRecordData(tririgaWS, "General", "cstVitralogyIdTX", id);
		return rd.getRecordData();
	} catch (error) {
		return null;
	}

}

function executeSqlQuery(bo,id,fields) {

	var resultData = [];

	if(id == null || id == "")
		return resultData;

	var query = java.lang.String.format("select * from T_%s where triidtx = '%s'", bo,id);

	var sqlConn = DBConnectionDAO.getConnection();
	var preparedStatement = sqlConn.prepareStatement(query);
	var resultSet = preparedStatement.executeQuery();

	while (resultSet.next()) {

		var result = new HashMap();

		fields.forEach(( function (val) {
			result.put(val,resultSet.getString(val))
		}));

		resultData.push(result);
	}
	DBConnectionDAO.cleanDB(resultSet, preparedStatement, null, sqlConn, null)
	log.trace("Sql Query Result : " + resultData);

	return resultData;
}

